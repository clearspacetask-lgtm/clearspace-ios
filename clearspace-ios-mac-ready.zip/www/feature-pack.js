import { addDoc, collection, doc, serverTimestamp, setDoc, updateDoc, writeBatch } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { GoogleAuthProvider, linkWithPopup, reauthenticateWithPopup, updateProfile } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

(() => {
  const boot = () => {
  const app = window.app;
  if (!app || app.__featurePackLoaded) return;
  app.__featurePackLoaded = true;

  const DEFAULT_STATUSES = [
    { id: 'todo', name: 'To Do', color: '#6b7280' },
    { id: 'progress', name: 'In Progress', color: '#2563eb' },
    { id: 'review', name: 'Review', color: '#d97706' },
    { id: 'done', name: 'Done', color: '#059669' },
  ];

  app.data.settings = Object.assign({ notificationsEnabled: false, customStatuses: [], taskTemplates: [], calendarWeekView: false }, app.data.settings || {});
  app.data.settings.customStatuses = Array.isArray(app.data.settings.customStatuses) ? app.data.settings.customStatuses : [];
  app.data.settings.taskTemplates = Array.isArray(app.data.settings.taskTemplates) ? app.data.settings.taskTemplates : [];

  const css = `
    html[data-theme="dark"] body, html[data-theme="dark"] { color-scheme: dark; }
    html[data-theme="dark"] body { background:#0b1220 !important; color:#e5e7eb !important; }
    html[data-theme="dark"] .pm-topbar,
    html[data-theme="dark"] .pm-sidebar,
    html[data-theme="dark"] .pm-dashboard-card,
    html[data-theme="dark"] .pm-modal-content,
    html[data-theme="dark"] .pm-task-row,
    html[data-theme="dark"] .pm-board-column,
    html[data-theme="dark"] .pm-empty-state-inner,
    html[data-theme="dark"] .pm-task-list,
    html[data-theme="dark"] .pm-comment-card,
    html[data-theme="dark"] .pm-detail-panel,
    html[data-theme="dark"] .pm-calendar-sync-card { background:#111827 !important; color:#e5e7eb !important; border-color:#273449 !important; }
    html[data-theme="dark"] .pm-input,
    html[data-theme="dark"] .pm-select,
    html[data-theme="dark"] textarea,
    html[data-theme="dark"] input { background:#0b1220 !important; color:#e5e7eb !important; border-color:#334155 !important; }
    html[data-theme="dark"] .pm-task-row:hover,
    html[data-theme="dark"] .pm-board-card:hover { background:#0f172a !important; }
    html[data-theme="dark"] .pm-helper-copy,
    html[data-theme="dark"] .pm-stat-label,
    html[data-theme="dark"] .pm-comment-meta { color:#94a3b8 !important; }
    html[data-theme="dark"] .pm-comment-text { color:#f8fafc !important; }
    html[data-theme="dark"] .pm-status-badge { border-color: transparent !important; }
    .cs-badge { display:inline-flex;align-items:center;gap:6px;padding:3px 8px;border-radius:999px;font-size:11px;font-weight:700;background:rgba(123,104,238,.12);color:#5b4bcc; }
    .cs-recurring { display:inline-flex;align-items:center;gap:4px;margin-left:8px;padding:2px 7px;border-radius:999px;font-size:10px;font-weight:700;background:rgba(99,102,241,.12);color:#4338ca; }
    .cs-drag-handle { cursor:grab; opacity:.65; user-select:none; font-size:18px; }
    .cs-shortcuts-overlay { position:fixed; inset:0; background:rgba(15,23,42,.45); display:none; align-items:center; justify-content:center; z-index:12000; }
    .cs-shortcuts-card { width:min(680px, calc(100vw - 24px)); background:#fff; border-radius:20px; padding:22px; box-shadow:0 30px 90px rgba(15,23,42,.28); }
    .cs-shortcuts-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:10px; margin-top:14px; }
    .cs-shortcut { padding:12px 14px; border:1px solid #e5e7eb; border-radius:14px; background:#f8fafc; display:flex; justify-content:space-between; gap:12px; }
    .cs-shortcut kbd { background:#111827; color:#fff; border-radius:6px; padding:2px 7px; font-size:12px; }
    .cs-mobile-nav { display:none; position:fixed; left:0; right:0; bottom:0; z-index:9998; background:#fff; border-top:1px solid #e5e7eb; box-shadow:0 -8px 30px rgba(15,23,42,.08); padding:8px max(10px, env(safe-area-inset-right)) calc(8px + env(safe-area-inset-bottom)) max(10px, env(safe-area-inset-left)); }
    .cs-mobile-nav-inner { display:grid; grid-template-columns:repeat(4,1fr); gap:6px; }
    .cs-mobile-nav button { border:0; background:transparent; padding:8px 6px; border-radius:14px; font-size:11px; font-weight:700; color:#475569; display:flex; flex-direction:column; gap:4px; align-items:center; justify-content:center; }
    .cs-mobile-nav button.active { background:rgba(123,104,238,.12); color:#6d5ce5; }
    .cs-mobile-nav button strong { font-size:16px; line-height:1; }
    .cs-calendar-connect { display:flex;align-items:center;gap:8px; }
    .cs-google-mark { width:19px;height:19px;display:grid;place-items:center;border-radius:6px;background:#fff;color:#4285f4;font-weight:900;box-shadow:inset 0 0 0 1px #dbe3ef; }
    .cs-calendar-events { margin:0 18px 18px;padding:15px;border:1px solid #e7e0f3;border-radius:15px;background:linear-gradient(145deg,#fbfaff,#f5f2ff); }
    .cs-calendar-events-head { display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:10px; }
    .cs-calendar-events-list { display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:8px; }
    .cs-calendar-event { padding:10px 11px;border:1px solid #e5e7eb;border-radius:10px;background:#fff; }
    .cs-calendar-event strong { display:block;font-size:12px;color:#312e42;white-space:nowrap;overflow:hidden;text-overflow:ellipsis; }
    .cs-calendar-event span { display:block;margin-top:4px;color:#7b728c;font-size:11px; }
    @media (max-width: 767px) { body.cs-authenticated .cs-mobile-nav { display:block; } body.cs-authenticated { padding-bottom:74px; } }
    .cs-section { margin-top:14px; padding-top:14px; border-top:1px solid #e5e7eb; }
    .cs-section h4 { font-size:14px; margin-bottom:10px; }
    .cs-row { display:flex; gap:8px; flex-wrap:wrap; }
    .cs-pill { display:inline-flex;align-items:center;gap:6px;padding:7px 10px;border-radius:999px;border:1px solid #e5e7eb;background:#fff;font-size:12px; }
    .cs-template-item, .cs-status-item { display:flex; align-items:center; justify-content:space-between; gap:8px; padding:10px 12px; border:1px solid #e5e7eb; border-radius:12px; background:#fff; margin-top:8px; }
    .cs-template-item small, .cs-status-item small { color:#64748b; }
    .cs-template-fields { display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:8px; }
    .cs-template-field { display:flex;align-items:center;gap:8px;padding:9px 10px;border:1px solid #e5e7eb;border-radius:11px;background:#fff;font-size:12px;font-weight:650;cursor:pointer; }
    .cs-template-field:has(input:checked) { border-color:#9a6ae8;background:#f6f1ff;color:#5b3ca0; }
    .cs-template-field input { width:16px;height:16px;accent-color:#7b68ee; }
    .cs-create-template-list { display:grid;gap:8px;margin-top:9px; }
    .cs-create-template-card { width:100%;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:11px 12px;border:1px solid #e6dcef;border-radius:13px;background:linear-gradient(145deg,#fff,#faf7ff);color:#352b42;text-align:left;cursor:pointer;transition:.16s ease; }
    .cs-create-template-card:hover { border-color:#a98adb;background:#f6f0ff;transform:translateY(-1px);box-shadow:0 7px 18px rgba(77,52,112,.09); }
    .cs-create-template-card strong { display:block;font-size:13px; }
    .cs-create-template-card small { display:block;margin-bottom:3px;color:#806e94;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.05em; }
    .cs-create-template-card .pm-icon-svg { color:#7652ad; }
    .cs-create-template-new { width:auto;justify-content:center;margin-top:10px;padding:8px 12px;box-shadow:none; }
    .cs-preview { padding:10px 12px; border-radius:12px; background:#f8fafc; border:1px solid #e5e7eb; line-height:1.6; font-size:13px; }
    .cs-chart { display:flex; align-items:flex-end; gap:10px; min-height:120px; margin-top:10px; }
    .cs-chart-bar { flex:1; display:flex; flex-direction:column; align-items:center; gap:8px; }
    .cs-chart-bar > div { width:100%; border-radius:10px 10px 4px 4px; background:linear-gradient(180deg, #7b68ee, #4f46e5); min-height:10px; }
    .cs-mini-note { font-size:12px; color:#64748b; margin-top:6px; }
    .cs-import { display:none; }
    .cs-toast-region { position:fixed;right:18px;bottom:18px;z-index:15000;display:grid;gap:9px;width:min(360px,calc(100vw - 28px));pointer-events:none; }
    .cs-toast { display:flex;align-items:flex-start;gap:10px;padding:12px 14px;border:1px solid rgba(125,84,52,.16);border-radius:14px;background:#fffdf9;color:#49362a;box-shadow:0 16px 42px rgba(54,33,21,.18);font-size:13px;font-weight:700;line-height:1.4;animation:cs-toast-in .18s ease-out; }
    .cs-toast::before { content:'✓';display:grid;place-items:center;flex:0 0 21px;height:21px;border-radius:50%;background:#dcfce7;color:#047857;font-size:12px; }
    .cs-toast.is-error::before { content:'!';background:#fee2e2;color:#b91c1c; }
    .cs-toast.is-leaving { opacity:0;transform:translateY(6px);transition:.18s ease; }
    @keyframes cs-toast-in { from { opacity:0;transform:translateY(8px); } }
    @media (max-width: 900px) {
      .pm-toolbar { flex-wrap: wrap; align-items: stretch; gap: 10px; }
      .pm-mobile-view-picker { width: 100%; order: 1; }
      .pm-mobile-view-picker > span { display:none; }
      .pm-mobile-view-picker .pm-select { width: 100%; }
      .pm-view-tabs { width: 100%; order: 2; overflow-x: auto; -webkit-overflow-scrolling: touch; padding-bottom: 2px; }
      .pm-toolbar-actions { width: 100%; order: 3; justify-content: flex-end; flex-wrap: wrap; }
      .pm-board { display:flex; gap:16px; overflow-x:auto; scroll-snap-type:x mandatory; padding-bottom: 10px; }
      .pm-board-column { flex:0 0 calc(100vw - 32px); min-width:calc(100vw - 32px); scroll-snap-align:start; }
      .pm-board-tasks { gap:12px; }
    }
  `;
  const style = document.createElement('style');
  style.textContent = css;
  document.head.appendChild(style);

  const qs = (sel, root = document) => root.querySelector(sel);
  const qsa = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const today = () => new Date().toISOString().split('T')[0];
  const escapeHTML = (str = '') => app.escapeHTML ? app.escapeHTML(str) : String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');

  app.showToast = function showToast(message, options = {}) {
    if (!message) return;
    let region = document.getElementById('cs-toast-region');
    if (!region) {
      region = document.createElement('div');
      region.id = 'cs-toast-region';
      region.className = 'cs-toast-region';
      region.setAttribute('role', 'status');
      region.setAttribute('aria-live', 'polite');
      region.setAttribute('aria-atomic', 'false');
      document.body.appendChild(region);
    }
    const toast = document.createElement('div');
    toast.className = `cs-toast${options.type === 'error' ? ' is-error' : ''}`;
    toast.textContent = String(message);
    region.appendChild(toast);
    while (region.children.length > 3) region.firstElementChild?.remove();
    window.setTimeout(() => {
      toast.classList.add('is-leaving');
      window.setTimeout(() => { toast.remove(); if (!region.children.length) region.remove(); }, 200);
    }, Math.max(1800, Number(options.duration) || 3200));
  };

  function statusDefs() {
    return [...DEFAULT_STATUSES, ...(app.data.settings.customStatuses || [])];
  }
  function statusMeta(value) {
    return statusDefs().find(s => s.id === value) || DEFAULT_STATUSES.find(s => s.id === value) || { id: value, name: value || 'Todo', color: '#6b7280' };
  }
  function normalizeRecurrence(value) {
    if (!value || value === 'none') return { frequency:'none', interval:1, weekDays:[] };
    if (typeof value === 'string') return { frequency:value, interval:1, weekDays:[] };
    return { frequency:'none', interval:1, weekDays:[], monthMode:'day', monthDay:1, endType:'never', endDate:'', ...value };
  }
  function recurringLabel(value) {
    const rule = normalizeRecurrence(value);
    if (rule.frequency === 'none') return 'None';
    const names = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
    const unit = { daily:'day', weekly:'week', monthly:'month', yearly:'year' }[rule.frequency] || rule.frequency;
    const days = rule.frequency === 'weekly' && rule.weekDays?.length ? ` on ${rule.weekDays.map(day => names[day]).join(', ')}` : '';
    return `Every ${rule.interval > 1 ? `${rule.interval} ` : ''}${unit}${rule.interval > 1 ? 's' : ''}${days}`;
  }
  function recurringNextDate(due, value) {
    const recurring = normalizeRecurrence(value);
    if (!due || recurring.frequency === 'none') return '';
    const d = new Date(`${due}T00:00:00`);
    if (Number.isNaN(d.getTime())) return '';
    const interval = Math.max(1, Number(recurring.interval) || 1);
    if (recurring.frequency === 'daily') d.setDate(d.getDate() + interval);
    if (recurring.frequency === 'weekly') {
      const selected = (recurring.weekDays?.length ? recurring.weekDays : [d.getDay()]).slice().sort((a,b) => a-b);
      const later = selected.find(day => day > d.getDay());
      d.setDate(d.getDate() + (later !== undefined ? later - d.getDay() : interval * 7 - (d.getDay() - selected[0])));
    }
    if (recurring.frequency === 'monthly') {
      const sourceDay = d.getDate();
      if (recurring.monthMode === 'weekday') {
        const weekday = d.getDay(), ordinal = Math.ceil(sourceDay / 7);
        d.setDate(1); d.setMonth(d.getMonth() + interval);
        const targetMonth = d.getMonth();
        d.setDate(1 + ((weekday - d.getDay() + 7) % 7) + (ordinal - 1) * 7);
        if (d.getMonth() !== targetMonth) d.setDate(d.getDate() - 7);
      } else {
        const target = Number(recurring.monthDay) || sourceDay;
        d.setDate(1); d.setMonth(d.getMonth() + interval);
        const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
        d.setDate(Math.min(target, last));
      }
    }
    if (recurring.frequency === 'yearly') d.setFullYear(d.getFullYear() + interval);
    const next = app.dateInputValue ? app.dateInputValue(d) : d.toISOString().split('T')[0];
    return recurring.endType === 'date' && recurring.endDate && next > recurring.endDate ? '' : next;
  }
  function csvEscape(value) {
    return `"${String(value ?? '').replace(/"/g, '""')}"`;
  }
  function parseCsv(text) {
    const rows = [];
    let row = [], cell = '', inQuotes = false;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i], next = text[i + 1];
      if (inQuotes) {
        if (ch === '"' && next === '"') { cell += '"'; i++; }
        else if (ch === '"') inQuotes = false;
        else cell += ch;
      } else if (ch === '"') inQuotes = true;
      else if (ch === ',') { row.push(cell); cell = ''; }
      else if (ch === '\n') { row.push(cell); rows.push(row); row = []; cell = ''; }
      else if (ch !== '\r') cell += ch;
    }
    row.push(cell);
    if (row.some(Boolean)) rows.push(row);
    return rows;
  }
  function download(filename, content, mime = 'text/plain;charset=utf-8') {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  function markdownToHtml(input = '') {
    const blocks = String(input).replace(/\r/g, '').split('\n');
    let html = '';
    let inList = false, inCode = false;
    const closeList = () => { if (inList) { html += '</ul>'; inList = false; } };
    const closeCode = () => { if (inCode) { html += '</code></pre>'; inCode = false; } };
    for (const raw of blocks) {
      const line = escapeHTML(raw);
      if (line.startsWith('```')) { if (inCode) closeCode(); else { closeList(); html += '<pre class="cs-preview"><code>'; inCode = true; } continue; }
      if (inCode) { html += `${line}\n`; continue; }
      if (/^#{1,3}\s/.test(line)) { closeList(); const lvl = line.match(/^#{1,3}/)[0].length; html += `<h${lvl}>${line.slice(lvl).trim()}</h${lvl}>`; continue; }
      if (/^[-*]\s+/.test(line)) { if (!inList) { html += '<ul>'; inList = true; } html += `<li>${line.replace(/^[-*]\s+/, '')}</li>`; continue; }
      closeList();
      if (!line.trim()) { html += '<br>'; continue; }
      let out = line
        .replace(/\[([^\]]+)\]\((https?:[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>')
        .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
        .replace(/\*([^*]+)\*/g, '<em>$1</em>')
        .replace(/`([^`]+)`/g, '<code>$1</code>');
      html += `<p>${out}</p>`;
    }
    closeList(); closeCode();
    return html || '<p></p>';
  }
  function taskTimeMinutes(task) {
    const seconds = Number(task.timeSeconds) || 0;
    if (seconds) return Math.round(seconds / 60);
    const match = /(?:(\d+)h)?\s*(?:(\d+)m)?/.exec(task.time || '') || [];
    return (Number(match[1]) || 0) * 60 + (Number(match[2]) || 0);
  }
  function fmtMinutes(m) {
    return `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, '0')}m`;
  }
  function setTheme() {
    const theme = app.data.settings.theme === 'system'
      ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
      : app.data.settings.theme;
    document.documentElement.dataset.theme = theme === 'dark' ? 'dark' : 'light';
    document.body?.classList.toggle('theme-dark', theme === 'dark');
  }
  function saveSettingsMerge(patch) {
    app.data.settings = Object.assign({}, app.data.settings, patch);
    return app.data.user ? setDoc(doc(window.fbDb, 'clearspace_users', app.data.user.uid), { settings: app.data.settings }, { merge: true }) : Promise.resolve();
  }
  function currentTemplateOptions() {
    const items = app.data.settings.taskTemplates || [];
    return ['<option value="">Use template...</option>', ...items.map((t, i) => `<option value="${i}">${escapeHTML(t.name)}</option>`)].join('');
  }
  function templateOrdinal(index) {
    const words = ['first','second','third','fourth','fifth','sixth','seventh','eighth','ninth','tenth'];
    return words[index] || `${index + 1}th`;
  }
  function renderCreateTemplatePicker() {
    const mount = qs('#cs-create-template-picker');
    if (!mount) return;
    const templates = app.data.settings.taskTemplates || [];
    mount.innerHTML = templates.length
      ? `<div class="cs-mini-note">Choose one to apply it instantly.</div><div class="cs-create-template-list">${templates.map((template, index) => `<button type="button" class="cs-create-template-card" data-template-index="${index}"><span><small>Your ${templateOrdinal(index)} template</small><strong>${escapeHTML(template.name)}</strong></span>${window.csIcon('chevronRight')}</button>`).join('')}</div>`
      : '<div style="padding:12px;border:1px dashed #cbb8e9;border-radius:12px;background:#faf7ff;"><strong style="display:block;font-size:13px;">Create template</strong><div class="cs-mini-note">Choose the menus and default priority for your New Task screen.</div></div>';
    mount.insertAdjacentHTML('beforeend', '<button type="button" class="pm-btn-ghost cs-create-template-new">+ Create template</button>');
  }
  function getCreateValue(id) {
    return qs(id)?.value?.trim() || '';
  }
  function refreshTemplateControls() {
    renderCreateTemplatePicker();
    renderTemplateList();
  }
  function applyTemplateToCreate(tpl) {
    if (!tpl) return false;
    const supported = ['status','assignee','space','project','description','tags','estimate'];
    const inferred = [
      tpl.status && 'status', tpl.assigneeId && 'assignee', tpl.spaceId && 'space', tpl.project && 'project',
      tpl.description && 'description', tpl.tags?.length && 'tags', tpl.estimate && 'estimate'
    ].filter(Boolean);
    app.data.createFields = [...new Set([...(tpl.visibleFields || []), ...inferred])].filter(field => supported.includes(field));
    app.renderCreateFields();
    const setValue = (selector, value) => { const element = qs(selector); if (element && value !== undefined && value !== null) element.value = value; };
    setValue('#new-task-name', tpl.taskName ?? tpl.name ?? '');
    setValue('#new-task-priority', tpl.priority || 'medium');
    setValue('#new-task-status', tpl.status || 'todo');
    setValue('#new-task-assignee', tpl.assigneeId || 'unassigned');
    setValue('#new-task-space', tpl.spaceId || '');
    setValue('#new-task-project', tpl.project || '');
    setValue('#new-task-desc', tpl.description || '');
    setValue('#new-task-estimate', tpl.estimate || '');
    setValue('#new-task-tags', (tpl.tags || []).join(', '));
    app.setCreateRecurrence?.(tpl.recurrence || { frequency:tpl.recurring || 'none' });
    app.enhanceCreateSelects?.();
    return true;
  }
  function injectCreateControls() {
    const modal = qs('#create-modal .pm-modal-body');
    if (!modal || qs('#cs-create-controls')) return;
    const wrap = document.createElement('div');
    wrap.id = 'cs-create-controls';
    wrap.innerHTML = `
      <div class="cs-section">
        <h4>Templates</h4>
        <div id="cs-create-template-picker"></div>
      </div>`;
    modal.insertBefore(wrap, qs('#create-optional-fields'));
    renderCreateTemplatePicker();
    qs('#cs-create-template-picker')?.addEventListener('click', event => {
      const templateButton = event.target.closest('[data-template-index]');
      if (templateButton) {
        const template = app.data.settings.taskTemplates?.[Number(templateButton.dataset.templateIndex)];
        if (applyTemplateToCreate(template)) app.showToast?.('Template applied');
        return;
      }
      if (event.target.closest('.cs-create-template-new')) app.saveCurrentTaskAsTemplate?.(null);
    });
  }
  function injectSettingsControls() {
    const body = qs('#settings-modal .pm-modal-body');
    if (!body || qs('#cs-settings-controls')) return;
    const div = document.createElement('div');
    div.id = 'cs-settings-controls';
    div.innerHTML = `
      <div class="cs-section">
        <h4>Notifications</h4>
        <label class="cs-pill"><input type="checkbox" id="cs-notifications-toggle"> Enable due-date reminders</label>
        <div class="cs-mini-note">You'll get a browser notification when tasks are due today.</div>
      </div>
      <div class="cs-section">
        <h4>Templates</h4>
        <div class="cs-mini-note">Choose which task menus appear first and the priority they start with.</div>
        <div class="cs-row" style="margin-top:10px;"><button type="button" class="pm-btn-ghost" id="cs-save-template-btn">Create task template</button></div>
        <div id="cs-template-list"></div>
      </div>
      <div class="cs-section">
        <h4>Custom statuses</h4>
        <div class="cs-row"><input class="pm-input" id="cs-status-name" placeholder="Name" style="flex:1;min-width:120px;"><input class="pm-input" type="color" id="cs-status-color" value="#7b68ee" style="width:64px;height:40px;padding:4px;"><button class="pm-btn-ghost" type="button" id="cs-add-status-btn">Add</button></div>
        <div id="cs-status-list"></div>
      </div>
      <div class="cs-section">
        <h4>Data</h4>
        <div class="cs-row" style="gap:10px;"><button type="button" class="pm-btn-ghost" id="cs-export-csv">Export CSV</button><button type="button" class="pm-btn-ghost" id="cs-import-csv">Import CSV</button><input type="file" id="cs-import-file" class="cs-import" accept=".csv,text/csv"></div>
      </div>
      <div class="cs-section">
        <h4>Integrations</h4>
        <div class="cs-template-item"><div><strong>Google Calendar</strong><div class="cs-mini-note" id="cs-calendar-status-text">${app.data.calendarSync?.connected ? 'Connected' : 'Not connected'}</div></div><small>${app.data.calendarSync?.connected ? 'On' : 'Off'}</small></div>
        <div class="cs-status-item" aria-disabled="true" style="opacity:.55;pointer-events:none;"><div><strong>Slack</strong><div class="cs-mini-note">Coming soon</div></div><small>Coming soon</small></div>
        <div class="cs-status-item" aria-disabled="true" style="opacity:.55;pointer-events:none;"><div><strong>Notion</strong><div class="cs-mini-note">Coming soon</div></div><small>Coming soon</small></div>
        <div class="cs-status-item" aria-disabled="true" style="opacity:.55;pointer-events:none;"><div><strong>Google Tasks</strong><div class="cs-mini-note">Coming soon</div></div><small>Coming soon</small></div>
      </div>`;
    body.appendChild(div);
    qs('#cs-notifications-toggle').checked = Boolean(app.data.settings.notificationsEnabled);
    qs('#cs-notifications-toggle').addEventListener('change', async e => {
      if (e.target.checked && 'Notification' in window && Notification.permission === 'default') {
        const permission = await Notification.requestPermission().catch(() => 'denied');
        if (permission !== 'granted') e.target.checked = false;
      }
      await saveSettingsMerge({ notificationsEnabled: e.target.checked });
    });
    qs('#cs-save-template-btn').addEventListener('click', () => app.saveCurrentTaskAsTemplate?.(null));
    qs('#cs-add-status-btn').addEventListener('click', () => {
      const name = qs('#cs-status-name').value.trim();
      const color = qs('#cs-status-color').value || '#7b68ee';
      if (!name) return;
      const next = [...(app.data.settings.customStatuses || []), { id: `custom-${Date.now()}`, name, color }].slice(-24);
      saveSettingsMerge({ customStatuses: next }).then(() => app.showSettings());
    });
    qs('#cs-export-csv').addEventListener('click', exportCsv);
    qs('#cs-import-csv').addEventListener('click', () => qs('#cs-import-file')?.click());
    qs('#cs-import-file').addEventListener('change', importCsv);
    renderTemplateList();
    renderStatusList();
  }
  function renderTemplateList() {
    const mount = qs('#cs-template-list');
    if (!mount) return;
    const templates = app.data.settings.taskTemplates || [];
    mount.innerHTML = templates.length ? templates.map((t, i) => `
      <div class="cs-template-item"><div><strong>${escapeHTML(t.name)}</strong><div class="cs-mini-note">${escapeHTML((t.priority || 'medium').replace(/^./, c => c.toUpperCase()))} priority · ${(t.visibleFields || []).filter(field => !['priority','due'].includes(field)).length || 0} extra menus</div></div><div class="cs-row"><button class="pm-btn-ghost" type="button" onclick="app.applyTemplate(${i})">Use</button><button class="pm-btn-icon" type="button" title="Delete template" aria-label="Delete ${escapeHTML(t.name)} template" onclick="app.removeTemplate(${i})">&times;</button></div></div>`).join('') : '<div class="cs-mini-note">No templates yet. Create one to set up your New Task screen.</div>';
  }
  function renderStatusList() {
    const mount = qs('#cs-status-list');
    if (!mount) return;
    const statuses = app.data.settings.customStatuses || [];
    mount.innerHTML = statuses.length ? statuses.map((s, i) => `<div class="cs-status-item"><div><strong>${escapeHTML(s.name)}</strong><div class="cs-mini-note">${escapeHTML(s.id)}</div></div><div class="cs-row"><span class="cs-pill"><span style="width:10px;height:10px;border-radius:50%;background:${s.color};display:inline-block"></span>${escapeHTML(s.color)}</span><button class="pm-btn-icon" type="button" aria-label="Delete ${escapeHTML(s.name)} status" onclick="app.removeCustomStatus(${i})">&times;</button></div></div>`).join('') : '<div class="cs-mini-note">No custom statuses yet.</div>';
  }
  function injectTopbarControls() {
    const actions = qs('.pm-topbar-actions');
    if (actions && !qs('#cs-theme-toggle')) {
      const btn = document.createElement('button');
      btn.className = 'pm-btn-ghost';
      btn.id = 'cs-theme-toggle';
      btn.type = 'button';
      btn.textContent = 'Theme';
      btn.addEventListener('click', () => {
        const next = app.data.settings.theme === 'dark' ? 'light' : 'dark';
        saveSettingsMerge({ theme: next }).then(() => { setTheme(); app.renderContent(); });
      });
      actions.prepend(btn);
    }
    if (!qs('#cs-mobile-nav')) {
      const nav = document.createElement('div');
      nav.id = 'cs-mobile-nav';
      nav.className = 'cs-mobile-nav';
      nav.innerHTML = `<div class="cs-mobile-nav-inner"><button data-view="home" aria-label="Switch to Home view"><svg class="pm-icon-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 11.5 12 4l9 7.5v8.5a1 1 0 0 1-1 1h-5.5v-6h-5v6H4a1 1 0 0 1-1-1z" fill="currentColor"/></svg><span>Home</span></button><button data-view="board" aria-label="Switch to Board view"><svg class="pm-icon-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h6v14H4zm10 0h6v14h-6zM12 5h1v14h-1z" fill="currentColor"/></svg><span>Board</span></button><button data-view="calendar" aria-label="Switch to Calendar view"><svg class="pm-icon-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 2.8v2.2H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2V2.8h-2V5H9V2.8Zm-2 6.2h14v10H5Z" fill="currentColor"/></svg><span>Calendar</span></button><button data-search="1" aria-label="Open search"><svg class="pm-icon-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M10 4a6 6 0 1 0 3.9 10.6l4.7 4.7 1.4-1.4-4.7-4.7A6 6 0 0 0 10 4Zm0 2a4 4 0 1 1 0 8 4 4 0 0 1 0-8Z" fill="currentColor"/></svg><span>Search</span></button></div>`;
      document.body.appendChild(nav);
      nav.addEventListener('click', (e) => {
        const btn = e.target.closest('button');
        if (!btn) return;
        if (btn.dataset.view) { app.setView(btn.dataset.view); app.navigate('home'); }
        if (btn.dataset.search) qs('#search-input')?.focus();
        if (btn.dataset.new) app.createTask();
      });
    }
    if (!qs('#cs-shortcuts-overlay')) {
      const overlay = document.createElement('div');
      overlay.id = 'cs-shortcuts-overlay';
      overlay.className = 'cs-shortcuts-overlay';
      overlay.innerHTML = `<div class="cs-shortcuts-card"><div style="display:flex;align-items:center;justify-content:space-between;gap:10px;"><strong>Keyboard shortcuts</strong><button class="pm-btn-icon" id="cs-shortcuts-close" aria-label="Close shortcuts">${window.csIcon('close')}</button></div><div class="cs-shortcuts-grid"><div class="cs-shortcut"><span>New task</span><kbd>n</kbd></div><div class="cs-shortcut"><span>Search</span><kbd>/</kbd></div><div class="cs-shortcut"><span>List / Board / Calendar / Timeline</span><kbd>1-4</kbd></div><div class="cs-shortcut"><span>Clear filters</span><kbd>c</kbd></div><div class="cs-shortcut"><span>Help overlay</span><kbd>?</kbd></div><div class="cs-shortcut"><span>Escape</span><kbd>Esc</kbd></div></div></div>`;
      document.body.appendChild(overlay);
      qs('#cs-shortcuts-close')?.addEventListener('click', () => overlay.style.display = 'none');
      overlay.addEventListener('click', e => { if (e.target === overlay) overlay.style.display = 'none'; });
    }
  }
  function ensureTaskListBindings() {
    qsa('.pm-task-row').forEach(row => {
      const idMatch = row.getAttribute('onclick')?.match(/openTask\('([^']+)'\)/);
      const taskId = row.dataset.taskId || idMatch?.[1];
      if (!taskId) return;
      row.dataset.taskId = taskId;
      row.draggable = true;
      if (!row.dataset.csBound) {
        row.dataset.csBound = '1';
        row.addEventListener('dragstart', ev => { ev.dataTransfer?.setData('text/plain', taskId); ev.dataTransfer.effectAllowed = 'move'; app.__dragTaskId = taskId; });
        row.addEventListener('dragover', ev => ev.preventDefault());
        row.addEventListener('drop', ev => { ev.preventDefault(); const src = ev.dataTransfer?.getData('text/plain') || app.__dragTaskId; if (src && src !== taskId) reorderTasks(src, taskId); });
      }
      if (!row.querySelector('.cs-drag-handle')) {
        const first = row.firstElementChild;
        first?.insertAdjacentHTML('beforeend', `<span class="cs-recurring" style="margin-left:10px;">${window.csIcon('grip')}</span>`);
      }
      const task = app.data.tasks.find(t => t.id === taskId);
      if (task && (task.recurrence?.frequency || task.recurring) && (task.recurrence?.frequency || task.recurring) !== 'none' && !row.querySelector('.cs-recurring-badge')) {
        const title = row.querySelector('.pm-task-title');
        if (title) title.insertAdjacentHTML('afterend', `<span class="cs-recurring-badge cs-recurring">${window.csIcon('repeat')} ${recurringLabel(task.recurrence || task.recurring)}</span>`);
      }
    });
  }
  function reorderTasks(sourceId, targetId) {
    const visible = app.getFilteredTasks().filter(Boolean);
    const ids = visible.map(t => t.id);
    const from = ids.indexOf(sourceId), to = ids.indexOf(targetId);
    if (from < 0 || to < 0) return;
    ids.splice(to, 0, ids.splice(from, 1)[0]);
    const batch = writeBatch(window.fbDb);
    ids.forEach((id, idx) => {
      batch.update(doc(window.fbDb, 'clearspace_tasks', id), { sortOrder: idx * 1000, updatedAt: serverTimestamp() });
    });
    batch.commit().then(() => app.showToast('Task order updated')).catch(err => console.error('Reorder failed', err));
  }
  function decorateDetailPanel() {
    const panel = qs('#detail-panel');
    const task = app.data.tasks.find(t => t.id === app.data.currentTaskId);
    if (!panel || !task) return;
    const body = qs('#detail-body', panel);
    if (!body) return;
    if (!qs('#detail-recurring')) {
      const section = document.createElement('div');
      section.className = 'pm-detail-section';
      section.innerHTML = `<div class="pm-detail-section-title">Recurring</div><div class="pm-detail-field"><div class="pm-detail-field-label">Repeat</div><div class="pm-detail-field-value"><select class="pm-detail-edit" id="detail-recurring"><option value="none">Does not repeat</option><option value="daily">Daily</option><option value="weekly">Weekly</option><option value="monthly">Monthly</option></select></div></div>`;
      body.insertBefore(section, body.children[1] || null);
      qs('#detail-recurring').value = task.recurring || 'none';
      qs('#detail-recurring').addEventListener('change', e => app.updateTaskField(task.id, 'recurring', e.target.value));
    }
    const desc = qs('.pm-detail-field textarea', body);
    if (desc && !qs('#detail-desc-preview')) {
      const preview = document.createElement('div');
      preview.id = 'detail-desc-preview';
      preview.className = 'cs-preview';
      preview.innerHTML = markdownToHtml(task.description || '');
      desc.insertAdjacentElement('afterend', preview);
      desc.addEventListener('input', () => { preview.innerHTML = markdownToHtml(desc.value); });
    }
    qsa('.pm-comment-text', body).forEach(el => { el.innerHTML = markdownToHtml(el.textContent || ''); });
    if (!qs('#cs-save-template-inline')) {
      const btn = document.createElement('button');
      btn.id = 'cs-save-template-inline';
      btn.className = 'pm-btn-ghost';
      btn.type = 'button';
      btn.textContent = 'Save template';
      btn.addEventListener('click', () => app.saveCurrentTaskAsTemplate(task.id));
      qs('.pm-detail-actions', panel)?.prepend(btn);
    }
  }
  function decorateGoalView() {
    if (app.data.currentPage !== 'goal' || !app.data.currentGoal) return;
    const goal = app.data.goals.find(g => g.id === app.data.currentGoal);
    const container = qs('#content-area');
    if (!goal || !container) return;
    const milestones = Array.isArray(goal.milestones) ? goal.milestones : [];
    const progress = milestones.length ? Math.round((milestones.filter(m => m.done).length / milestones.length) * 100) : Math.max(0, Math.min(100, Number(goal.progress) || 0));
    if (!qs('#cs-goal-milestones')) {
      container.insertAdjacentHTML('beforeend', `<div class="pm-dashboard-card" id="cs-goal-milestones" style="grid-column:1/-1;margin-top:12px;"><div class="pm-dashboard-card-title">Milestones</div><div class="pm-helper-copy">Progress is ${milestones.length ? 'calculated from milestones' : 'manual until you add milestones'}.</div><div class="cs-chart">${milestones.length ? milestones.map(m => `<div class="cs-chart-bar"><div style="height:${Math.max(12, progress)}%;opacity:${m.done ? 1 : 0.4};background:${m.done ? '#059669' : '#7b68ee'}"></div><span>${escapeHTML(m.name)}</span></div>`).join('') : '<div class="cs-mini-note">No milestones yet.</div>'}</div><div class="cs-row" style="margin-top:12px;"><button class="pm-btn-ghost" type="button" id="cs-add-milestone">Add milestone</button></div></div>`);
      qs('#cs-add-milestone')?.addEventListener('click', async () => {
        let modal = document.getElementById('milestone-create-modal');
        if (!modal) {
          modal = document.createElement('div');
          modal.id = 'milestone-create-modal';
          modal.className = 'pm-modal';
          modal.setAttribute('role', 'dialog');
          modal.setAttribute('aria-modal', 'true');
          modal.setAttribute('aria-labelledby', 'milestone-create-title');
          modal.setAttribute('aria-hidden', 'true');
          modal.inert = true;
          modal.style.display = 'none';
          modal.innerHTML = `
            <div class="pm-modal-overlay"></div>
            <div class="pm-modal-content">
              <div class="pm-modal-header">
                <h3 id="milestone-create-title">Add Milestone</h3>
                <button class="pm-btn-icon" type="button" data-close-milestone aria-label="Close milestone form">${window.csIcon('close')}</button>
              </div>
              <div class="pm-modal-body">
                <div class="pm-form-group">
                  <label for="milestone-create-name">Milestone name</label>
                  <input type="text" class="pm-input" id="milestone-create-name" placeholder="What should be completed next?">
                </div>
                <div id="milestone-create-error" style="display:none;color:#dc2626;font-size:13px;margin-top:8px;"></div>
              </div>
              <div class="pm-modal-footer">
                <button class="pm-btn-ghost" type="button" id="milestone-create-cancel">Cancel</button>
                <button class="pm-btn-primary" type="button" id="milestone-create-save">Add Milestone</button>
              </div>
            </div>`;
          document.body.appendChild(modal);
        }
        const close = () => {
          modal.style.display = 'none';
          modal.setAttribute('aria-hidden', 'true');
          modal.inert = true;
        };
        modal.querySelector('[data-close-milestone]')?.addEventListener('click', close);
        modal.querySelector('.pm-modal-overlay')?.addEventListener('click', close);
        modal.querySelector('#milestone-create-cancel')?.addEventListener('click', close);
        const nameInput = modal.querySelector('#milestone-create-name');
        const error = modal.querySelector('#milestone-create-error');
        nameInput.value = '';
        error.style.display = 'none';
        modal.querySelector('#milestone-create-save').onclick = async () => {
          const name = nameInput.value.trim();
          if (!name) { error.textContent = 'Milestone name is required.'; error.style.display = 'block'; nameInput.focus(); return; }
          const next = [...milestones, { name, done: false, date: today() }];
          await updateDoc(doc(window.fbDb, 'clearspace_goals', goal.id), { milestones: next, progress, updatedAt: serverTimestamp() });
          goal.milestones = next; app.showGoal(goal.id);
          close();
        };
        modal.style.display = 'flex';
        modal.setAttribute('aria-hidden', 'false');
        modal.inert = false;
        setTimeout(() => nameInput.focus(), 0);
      });
    }
  }
  function decorateTimeView() {
    if (app.data.currentPage !== 'time') return;
    const container = qs('#content-area');
    if (!container || qs('#cs-time-summary')) return;
    const tasks = app.data.tasks || [];
    const total = tasks.reduce((sum, task) => sum + taskTimeMinutes(task), 0);
    const bySpace = tasks.reduce((acc, task) => { acc[task.spaceId || 'No Space'] = (acc[task.spaceId || 'No Space'] || 0) + taskTimeMinutes(task); return acc; }, {});
    const week = tasks.reduce((acc, task) => { const d = task.due ? new Date(`${task.due}T00:00:00`) : null; if (!d) return acc; const weekKey = d.toISOString().slice(0,10); acc[weekKey] = (acc[weekKey] || 0) + taskTimeMinutes(task); return acc; }, {});
    const estimates = tasks.reduce((sum, task) => sum + (parseInt(String(task.estimate || '').match(/\d+/)?.[0] || '0', 10) || 0) * 60, 0);
    const actual = total;
    const mount = document.createElement('div');
    mount.id = 'cs-time-summary';
    mount.className = 'pm-dashboard';
    mount.style.gridColumn = '1/-1';
    mount.innerHTML = `<div class="pm-dashboard-card"><div class="pm-dashboard-card-title">Time Summary</div><div class="pm-stat-value">${fmtMinutes(total)}</div><div class="pm-stat-label">Tracked across all tasks</div></div><div class="pm-dashboard-card"><div class="pm-dashboard-card-title">Estimate vs Actual</div><div class="pm-stat-value">${fmtMinutes(estimates)}</div><div class="pm-stat-label">Estimates · Actual ${fmtMinutes(actual)}</div></div><div class="pm-dashboard-card"><div class="pm-dashboard-card-title">By Space</div>${Object.entries(bySpace).map(([k,v]) => `<div class="cs-pill" style="margin:6px 6px 0 0;">${escapeHTML(k)} · ${fmtMinutes(v)}</div>`).join('')}</div><div class="pm-dashboard-card"><div class="pm-dashboard-card-title">By Week</div>${Object.entries(week).map(([k,v]) => `<div class="cs-pill" style="margin:6px 6px 0 0;">${escapeHTML(k)} · ${fmtMinutes(v)}</div>`).join('')}</div>`;
    container.prepend(mount);
  }
  function injectCalendarTools() {
    if (app.data.currentView !== 'calendar') return;
    const nav = qs('.pm-calendar-nav');
    if (nav && !qs('#cs-week-toggle')) {
      const btn = document.createElement('button');
      btn.id = 'cs-week-toggle';
      btn.className = 'pm-btn-ghost';
      btn.type = 'button';
      btn.textContent = app.data.settings.calendarWeekView ? 'Month view' : 'Week view';
      btn.addEventListener('click', () => {
        app.data.settings.calendarWeekView = !app.data.settings.calendarWeekView;
        saveSettingsMerge({ calendarWeekView: app.data.settings.calendarWeekView }).then(() => app.renderContent());
      });
      nav.prepend(btn);
    }
    if (nav && !qs('#cs-google-calendar-connect')) {
      const connect = document.createElement('button');
      connect.id = 'cs-google-calendar-connect';
      connect.className = 'pm-btn-ghost cs-calendar-connect';
      connect.type = 'button';
      connect.innerHTML = `<span class="cs-google-mark">G</span><span>${app.data.calendarSync?.connected ? 'Google Calendar connected · Sync now' : 'Link with Google Calendar'}</span>`;
      connect.addEventListener('click', () => app.connectGoogleCalendar());
      nav.prepend(connect);
    }
    const calendar = qs('.pm-calendar');
    if (calendar && app.data.calendarSync?.connected && !qs('#cs-google-calendar-events')) {
      const events = app.data.googleCalendarEvents || [];
      const panel = document.createElement('section');
      panel.id = 'cs-google-calendar-events';
      panel.className = 'cs-calendar-events';
      panel.innerHTML = `<div class="cs-calendar-events-head"><strong>Google Calendar</strong><span class="cs-badge">${events.length} upcoming</span></div><div class="cs-calendar-events-list">${events.length ? events.slice(0, 8).map(event => `<div class="cs-calendar-event"><strong>${escapeHTML(event.summary || 'Untitled event')}</strong><span>${escapeHTML(event.when)}</span></div>`).join('') : '<div class="cs-mini-note">No upcoming Google Calendar events in the next 90 days.</div>'}</div>`;
      calendar.querySelector('.pm-calendar-header')?.insertAdjacentElement('afterend', panel);
    }
  }

  app.connectGoogleCalendar = async function connectGoogleCalendar() {
    if (!this.data.user || this.data.calendarConnecting) return;
    const button = qs('#cs-google-calendar-connect');
    this.data.calendarConnecting = true;
    if (button) { button.disabled = true; button.querySelector('span:last-child').textContent = 'Connecting...'; }
    try {
      const provider = new GoogleAuthProvider();
      provider.addScope('https://www.googleapis.com/auth/calendar.readonly');
      provider.addScope('https://www.googleapis.com/auth/calendar.events');
      provider.setCustomParameters({ prompt: 'consent', access_type: 'online' });
      const usesGoogle = this.data.user.providerData?.some(item => item.providerId === 'google.com');
      const result = usesGoogle ? await reauthenticateWithPopup(this.data.user, provider) : await linkWithPopup(this.data.user, provider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (!credential?.accessToken) throw new Error('Google did not return Calendar access.');
      this.data.calendarAccessToken = credential.accessToken;
      await this.syncAllTasksToGoogleCalendar();
      const start = new Date(), end = new Date(); end.setDate(end.getDate() + 90);
      const response = await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events?singleEvents=true&orderBy=startTime&maxResults=40&timeMin=${encodeURIComponent(start.toISOString())}&timeMax=${encodeURIComponent(end.toISOString())}`, { headers: { Authorization: `Bearer ${credential.accessToken}` } });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.error?.message || 'Google Calendar could not be loaded.');
      this.data.googleCalendarEvents = (payload.items || []).map(event => {
        const raw = event.start?.dateTime || event.start?.date;
        const date = raw ? new Date(raw.includes('T') ? raw : `${raw}T12:00:00`) : null;
        return { id: event.id, summary: event.summary || 'Untitled event', when: date && !Number.isNaN(date.valueOf()) ? new Intl.DateTimeFormat('en', { weekday:'short', month:'short', day:'numeric', ...(event.start?.dateTime ? { hour:'numeric', minute:'2-digit' } : {}) }).format(date) : 'Date unavailable' };
      });
      this.data.calendarSync = { connected: true, connectedAt: new Date().toISOString() };
      await setDoc(doc(window.fbDb, 'clearspace_users', this.data.user.uid), { calendarSync: this.data.calendarSync }, { merge: true });
      this.renderContent();
      this.showToast('Google Calendar connected and tasks synced');
    } catch (error) {
      console.error('Google Calendar connection failed:', error);
      this.showToast(error.code === 'auth/popup-closed-by-user' ? 'Google Calendar connection cancelled' : error.message || 'Could not connect Google Calendar');
    } finally {
      this.data.calendarConnecting = false;
      if (button?.isConnected) button.disabled = false;
    }
  };
  function nextCalendarDate(dateString) {
    const date = new Date(`${dateString}T12:00:00`);
    date.setDate(date.getDate() + 1);
    return date.toISOString().slice(0, 10);
  }

  function calendarEventId(task) {
    return task.googleCalendarEventIds?.[app.data.user?.uid] || '';
  }

  function calendarEventBody(task) {
    return {
      summary: task.name || 'ClearSpace task',
      description: [task.description || '', 'Created in ClearSpace'].filter(Boolean).join('\n\n'),
      start: { date: task.due },
      end: { date: nextCalendarDate(task.due) },
      extendedProperties: { private: { clearspaceTaskId: task.id } }
    };
  }

  async function calendarRequest(path, options = {}) {
    const token = app.data.calendarAccessToken;
    if (!token) return null;
    const response = await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events${path}`, {
      ...options,
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', ...(options.headers || {}) }
    });
    if (response.status === 204) return {};
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(payload.error?.message || 'Google Calendar could not be updated.');
      error.status = response.status;
      throw error;
    }
    return payload;
  }

  app.syncTaskToGoogleCalendar = async function syncTaskToGoogleCalendar(task, { remove = false } = {}) {
    if (!task?.id || !this.data.calendarAccessToken || !this.data.user) return;
    const eventId = calendarEventId(task);
    const shouldRemove = remove || !task.due || task.status === 'done';
    try {
      if (shouldRemove) {
        if (eventId) {
          try { await calendarRequest(`/${encodeURIComponent(eventId)}`, { method: 'DELETE' }); }
          catch (error) { if (error.status !== 404 && error.status !== 410) throw error; }
          await updateDoc(doc(window.fbDb, 'clearspace_tasks', task.id), { [`googleCalendarEventIds.${this.data.user.uid}`]: '' });
        }
        return;
      }
      let event;
      if (eventId) {
        try { event = await calendarRequest(`/${encodeURIComponent(eventId)}`, { method: 'PATCH', body: JSON.stringify(calendarEventBody(task)) }); }
        catch (error) { if (error.status !== 404 && error.status !== 410) throw error; }
      }
      if (!event) event = await calendarRequest('', { method: 'POST', body: JSON.stringify(calendarEventBody(task)) });
      if (event?.id && event.id !== eventId) {
        task.googleCalendarEventIds = { ...(task.googleCalendarEventIds || {}), [this.data.user.uid]: event.id };
        await updateDoc(doc(window.fbDb, 'clearspace_tasks', task.id), { [`googleCalendarEventIds.${this.data.user.uid}`]: event.id, googleCalendarSyncedAt: serverTimestamp() });
      }
    } catch (error) {
      console.error('Task calendar sync failed:', error);
      if (error.status === 401 || error.status === 403) {
        this.data.calendarAccessToken = '';
        this.showToast('Reconnect Google Calendar to keep syncing tasks');
      }
    }
  };

  app.syncAllTasksToGoogleCalendar = async function syncAllTasksToGoogleCalendar() {
    if (!this.data.calendarAccessToken) return;
    for (const task of [...(this.data.tasks || [])]) await this.syncTaskToGoogleCalendar(task);
  };

  function notifyDueTasks() {
    if (!app.data.settings.notificationsEnabled || !('Notification' in window)) return;
    if (Notification.permission !== 'granted') return;
    const due = (app.data.tasks || []).filter(task => task.due === today() && task.status !== 'done');
    if (!due.length) return;
    try { new Notification('ClearSpace', { body: `You have ${due.length} tasks due today.` }); } catch {}
  }
  function applyThemeAndUI() {
    setTheme();
    injectTopbarControls();
    injectCreateControls();
    injectSettingsControls();
    injectShortcutsListener();
    notifyDueTasks();
  }
  function injectShortcutsListener() {
    if (app.__csShortcutsBound) return;
    app.__csShortcutsBound = true;
    document.addEventListener('keydown', (e) => {
      const tag = (e.target?.tagName || '').toLowerCase();
      if (['input', 'textarea', 'select'].includes(tag) && e.key !== 'Escape') return;
      if (e.key === '?') { e.preventDefault(); const overlay = qs('#cs-shortcuts-overlay'); if (overlay) overlay.style.display = 'flex'; return; }
      if (e.key === 'n') { e.preventDefault(); app.createTask(); return; }
      if (e.key === '/') { e.preventDefault(); qs('#search-input')?.focus(); return; }
      if (e.key === '1') { e.preventDefault(); app.setView('list'); return; }
      if (e.key === '2') { e.preventDefault(); app.setView('board'); return; }
      if (e.key === '3') { e.preventDefault(); app.setView('calendar'); return; }
      if (e.key === '4') { e.preventDefault(); app.setView('timeline'); return; }
      if (e.key === 'c') { e.preventDefault(); app.clearTaskFilters?.(); return; }
    }, true);
  }
  async function exportCsv() {
    const rows = [['name','status','priority','due','project','description','tags']];
    (app.data.tasks || []).forEach(task => rows.push([task.name, task.status, task.priority, task.due, task.project, task.description, (task.tags || []).join('|')].map(csvEscape)));
    download(`clearspace-tasks-${today()}.csv`, rows.map(r => r.join(',')).join('\n'), 'text/csv;charset=utf-8');
  }
  async function importCsv(ev) {
    const file = ev.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = parseCsv(text);
      if (parsed.length < 2) throw new Error('CSV_EMPTY');
      const [header, ...rows] = parsed;
      const headers = header.map(h => h.toLowerCase().trim());
      const idx = key => headers.indexOf(key);
      if (idx('name') < 0) throw new Error('CSV_NAME_REQUIRED');
      const tasks = rows.filter(row => row.some(cell => cell.trim())).map(row => ({
        name: row[idx('name')]?.trim() || 'Imported task',
        status: row[idx('status')] || 'todo',
        priority: row[idx('priority')] || 'medium',
        due: row[idx('due')] || '',
        project: row[idx('project')] || '',
        description: row[idx('description')] || '',
        tags: (row[idx('tags')] || '').split('|').map(t => t.trim()).filter(Boolean),
        visibleFields: ['priority','due','description','tags'],
        subtasks: [], time: '0h 00m', timeSeconds: 0,
        userId: app.data.user?.uid, ownerId: app.data.workspace?.ownerId || app.data.user?.uid, workspaceId: app.data.currentWorkspaceId || app.data.workspace?.id || app.data.user?.uid,
        createdAt: serverTimestamp(),
      }));
      if (!tasks.length) throw new Error('CSV_EMPTY');
      const batch = writeBatch(window.fbDb);
      tasks.forEach(task => batch.set(doc(collection(window.fbDb, 'clearspace_tasks')), task));
      await batch.commit();
      app.showToast(`${tasks.length} task${tasks.length === 1 ? '' : 's'} imported`);
    } catch (error) {
      console.error('CSV import failed:', error);
      app.showToast(error.message === 'CSV_NAME_REQUIRED' ? 'CSV needs a name column' : error.message === 'CSV_EMPTY' ? 'CSV has no tasks to import' : 'CSV import failed. Please retry.');
    } finally {
      ev.target.value = '';
    }
  }

  const originalInit = app.init.bind(app);
  app.init = async function initFeaturePack() {
    await originalInit();
    applyThemeAndUI();
  };

  const originalLoadUserDataCalendar = app.loadUserData.bind(app);
  app.loadUserData = async function loadUserDataCalendar() {
    const userData = await originalLoadUserDataCalendar();
    this.data.calendarSync = userData?.calendarSync || { connected: false };
    return userData;
  };

  const originalRenderTaskRow = app.renderTaskRow.bind(app);
  app.renderTaskRow = function renderTaskRowFeaturePack(task) {
    const today = new Date().toISOString().split('T')[0];
    const dueClass = !task.due ? '' : task.due < today ? 'pm-due-overdue' : task.due === today ? 'pm-due-soon' : 'pm-due-ok';
    const status = statusMeta(task.status);
    const priorityClass = `pm-priority-${task.priority}-dot`;
    const assigneeInitials = (task.assignee || 'U').split(' ').map(n => n[0]).join('').toUpperCase();
    const assigneeFirst = (task.assignee || 'Unassigned').split(' ')[0];
    const tags = task.tags || [];
    const time = task.time || '0h 00m';
    return `
      <div class="pm-task-row" role="button" tabindex="0" data-task-id="${task.id}" draggable="true" onclick="app.openTask('${task.id}')">
        <div class="pm-task-checkbox ${task.status === 'done' ? 'checked' : ''}" role="checkbox" tabindex="0" aria-checked="${task.status === 'done'}" aria-label="Mark ${escapeHTML(task.name)} complete" onclick="event.stopPropagation(); app.toggleTask('${task.id}')">${task.status === 'done' ? '&#10003;' : ''}</div>
        <div class="pm-task-name"><span class="cs-drag-handle">${window.csIcon('grip')}</span><span class="pm-task-title">${escapeHTML(task.name)}</span>${(task.recurrence?.frequency || task.recurring) && (task.recurrence?.frequency || task.recurring) !== 'none' ? `<span class="cs-recurring">${window.csIcon('repeat')} ${recurringLabel(task.recurrence || task.recurring)}</span>` : ''}${tags.map(t => `<span class="pm-tag">${escapeHTML(t)}</span>`).join('')}</div>
        <div class="pm-task-meta"><div class="pm-avatar pm-avatar-sm">${escapeHTML(assigneeInitials)}</div><span>${escapeHTML(assigneeFirst)}</span></div>
        <div><span class="pm-status-badge pm-status-${status.id}" style="${status.color ? `background:${status.color}16;color:${status.color};` : ''}"><span style="width:6px;height:6px;border-radius:50%;background:currentColor;display:inline-block;margin-right:4px;"></span>${escapeHTML(status.name)}</span></div>
        <div class="pm-due-date ${dueClass}">${task.due ? escapeHTML(app.formatDueDateLabel?.(task.due) || task.due) : '<span style="color:#9ca3af;">No due date</span>'}</div>
        <div class="pm-task-meta"><div class="pm-priority-dot ${priorityClass}"></div> ${escapeHTML(task.priority)}</div>
        <div class="pm-task-meta">${window.csIcon('timer')} ${escapeHTML(time)}</div>
        <div style="text-align:center;color:#d1d5db;">&#8942;</div>
      </div>
    `;
  };

  const originalRenderEditableTaskField = app.renderEditableTaskField.bind(app);
  app.renderEditableTaskField = function renderEditableTaskFieldFeaturePack(task, field) {
    if (field === 'status') {
      const option = (value, label, current, color = '') => `<option value="${value}" ${current === value ? 'selected' : ''}>${label}</option>`;
      const statuses = statusDefs();
      const wrap = (label, control) => `<div class="pm-detail-field" data-task-field="${field}"><div class="pm-detail-field-label">${label}</div><div class="pm-detail-field-value">${control}</div></div>`;
      return wrap('Status', `<select class="pm-detail-edit" onchange="app.updateTaskField('${task.id}', 'status', this.value)">${statuses.map(s => option(s.id, s.name, task.status, s.color)).join('')}</select>`);
    }
    return originalRenderEditableTaskField(task, field);
  };

  const originalRenderListView = app.renderListView.bind(app);
  app.renderListView = function renderListViewFeaturePack(container) {
    const tasks = this.getFilteredTasks();
    if (!this.data.groupByStatus) return originalRenderListView(container);
    if (!tasks.length) return originalRenderListView(container);
    const groups = statusDefs();
    container.innerHTML = `<div class="pm-fade-in">${groups.map(({ id, name, color }) => {
      const groupTasks = tasks.filter(t => t.status === id);
      return `<div style="margin-bottom:18px;"><div style="padding:10px 14px;font-weight:700;color:#4b5563;display:flex;justify-content:space-between;align-items:center;"><span>${escapeHTML(name)}</span><span class="pm-badge" style="${color ? `background:${color}16;color:${color};` : ''}">${groupTasks.length}</span></div><div class="pm-task-list"><div class="pm-task-header"><div></div><div>Task Name</div><div>Assignee</div><div>Status</div><div>Due Date</div><div>Priority</div><div>Time</div><div></div></div>${groupTasks.length ? groupTasks.map(task => this.renderTaskRow(task)).join('') : '<div style="padding:18px;color:#9ca3af;">No tasks in this group.</div>'}</div></div>`;
    }).join('')}</div>`;
  };

  const originalRenderBoardView = app.renderBoardView.bind(app);
  app.renderBoardView = function renderBoardViewFeaturePack(container) {
    const tasks = this.getFilteredTasks();
    const cols = statusDefs();
    container.innerHTML = `<div class="pm-board pm-fade-in">${cols.map(col => {
      const colTasks = tasks.filter(t => t.status === col.id);
      return `<div class="pm-board-column"><div class="pm-board-header"><span>${escapeHTML(col.name)}</span><span class="pm-board-count" style="${col.color ? `background:${col.color}16;color:${col.color};` : ''}">${colTasks.length}</span></div><div class="pm-board-tasks">${colTasks.map(task => `<div class="pm-board-card" role="button" tabindex="0" onclick="app.openTask('${task.id}')"><div class="pm-board-card-title">${escapeHTML(task.name)}</div><div class="pm-board-card-tags">${(task.tags || []).map(t => `<span class="pm-tag">${escapeHTML(t)}</span>`).join('')}</div><div class="pm-board-card-bottom"><div class="pm-task-meta"><div class="pm-priority-dot pm-priority-${task.priority}-dot"></div><span style="font-size:12px;color:#9ca3af;">${task.due ? escapeHTML(app.formatDueDateLabel?.(task.due) || task.due) : 'No due date'}</span></div><div class="pm-avatar pm-avatar-sm">${escapeHTML((task.assignee || 'U').split(' ').map(n => n[0]).join('').toUpperCase())}</div></div></div>`).join('')}<button class="pm-btn-ghost" style="justify-content:center;margin-top:4px;" onclick="app.createTask()">+ Add Task</button></div></div>`;
    }).join('')}</div>`;
  };

  const originalRenderCalendarView = app.renderCalendarView.bind(app);
  app.renderCalendarView = function renderCalendarViewFeaturePack(container) {
    if (!this.data.settings.calendarWeekView) return originalRenderCalendarView(container);
    const now = this.data.calendarDate || new Date();
    const start = new Date(now);
    start.setDate(start.getDate() - start.getDay() + (this.data.settings.weekStart === 'monday' ? 1 : 0));
    const days = [];
    for (let i = 0; i < 7; i++) { const d = new Date(start); d.setDate(start.getDate() + i); days.push(d); }
    const tasks = this.getFilteredTasks();
    const monthName = new Intl.DateTimeFormat('en', { month: 'long', year: 'numeric' }).format(now);
    const todayStr = today();
    container.innerHTML = `<div class="pm-calendar pm-fade-in"><div class="pm-calendar-header"><div class="pm-calendar-title">${monthName} · Week</div><div class="pm-calendar-nav"><button class="pm-btn-ghost" onclick="app.goCalendarToday()">Today</button><button class="pm-btn-icon" onclick="app.shiftCalendar(-1)" aria-label="Previous week">${window.csIcon('chevronLeft')}</button><button class="pm-btn-icon" onclick="app.shiftCalendar(1)" aria-label="Next week">${window.csIcon('chevronRight')}</button></div></div><div class="pm-calendar-grid">${days.map(d => `<div class="pm-calendar-day-header ${d.toISOString().split('T')[0] === todayStr ? 'today' : ''}">${new Intl.DateTimeFormat('en', { weekday:'short' }).format(d)}</div>`).join('')}${days.map(d => {
      const key = d.toISOString().split('T')[0];
      const dayTasks = tasks.filter(t => t.due === key);
      const colors = statusDefs().reduce((acc, s) => (acc[s.id] = s.color, acc), {});
      return `<div class="pm-calendar-day ${key === todayStr ? 'today' : ''}" data-date="${key}"><div class="pm-calendar-day-number">${d.getDate()}</div>${dayTasks.map(t => `<div class="pm-calendar-task" role="button" tabindex="0" onclick="app.openTask('${t.id}')" draggable="true" data-task-id="${t.id}" style="background:${(colors[t.status] || '#6b7280')}15;color:${colors[t.status] || '#6b7280'};border-left:3px solid ${colors[t.status] || '#6b7280'};cursor:pointer;">${escapeHTML(t.name)}</div>`).join('')}</div>`;
    }).join('')}</div></div>`;
    qsa('.pm-calendar-task', container).forEach(el => {
      el.addEventListener('dragstart', ev => ev.dataTransfer?.setData('text/plain', el.dataset.taskId || ''));
      el.addEventListener('dragover', ev => ev.preventDefault());
      el.addEventListener('drop', async ev => {
        ev.preventDefault();
        const id = ev.dataTransfer?.getData('text/plain');
        const task = app.data.tasks.find(t => t.id === id);
        const date = el.closest('.pm-calendar-day')?.dataset.date;
        if (!task || !date) return;
        try {
          task.due = date;
          await updateDoc(doc(window.fbDb, 'clearspace_tasks', task.id), { due: date, updatedAt: serverTimestamp() });
          await app.syncTaskToGoogleCalendar?.(task);
          app.showToast('Task rescheduled');
        } catch (error) { console.error(error); }
      });
    });
  };

  const originalShiftCalendar = app.shiftCalendar.bind(app);
  app.shiftCalendar = function shiftCalendarFeaturePack(direction) {
    if (!this.data.settings.calendarWeekView) return originalShiftCalendar(direction);
    const next = new Date(this.data.calendarDate || new Date());
    next.setDate(next.getDate() + (Number(direction) || 0) * 7);
    this.data.calendarDate = next;
    this.renderContent();
  };

  const originalUpdateTaskField = app.updateTaskField.bind(app);
  app.updateTaskField = async function updateTaskFieldFeaturePack(taskId, field, value) {
    if (field === 'recurring') {
      const task = this.data.tasks.find(t => t.id === taskId);
      if (!task) return;
      const previous = task.recurring || 'none';
      const next = value || 'none';
      task.recurring = next;
      try {
        await updateDoc(doc(window.fbDb, 'clearspace_tasks', taskId), { recurring: next, updatedAt: serverTimestamp() });
        this.showToast('Task saved');
      } catch (err) {
        task.recurring = previous;
        throw err;
      }
      return;
    }
    const result = await originalUpdateTaskField(taskId, field, value);
    if (['name', 'due', 'status', 'description'].includes(field)) {
      const task = this.data.tasks.find(t => t.id === taskId);
      if (task) await this.syncTaskToGoogleCalendar?.(task);
    }
    return result;
  };

  app.applyTemplate = function applyTemplate(index) {
    const tpl = this.data.settings.taskTemplates?.[index];
    if (!tpl) return;
    const createModal = qs('#create-modal');
    if (!createModal || createModal.style.display === 'none') {
      this.closeSettings?.();
      this.createTask();
      setTimeout(() => { applyTemplateToCreate(tpl); this.showToast?.('Template applied'); }, 0);
      return;
    }
    applyTemplateToCreate(tpl);
    this.showToast?.('Template applied');
  };

  app.saveCurrentTaskAsTemplate = async function saveCurrentTaskAsTemplate(taskId = this.data.currentTaskId) {
    const task = this.data.tasks.find(t => t.id === taskId) || {
      name:'', priority:this.data.settings.defaultPriority || 'medium', status:'todo', description:'', tags:[], estimate:'', project:'',
      visibleFields:['priority','due'], recurring:'none', recurrence:null, assigneeId:'unassigned', spaceId:''
    };
    let modal = document.getElementById('template-save-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'template-save-modal';
      modal.className = 'pm-modal';
      modal.setAttribute('role', 'dialog');
      modal.setAttribute('aria-modal', 'true');
      modal.setAttribute('aria-labelledby', 'template-save-title');
      modal.setAttribute('aria-hidden', 'true');
      modal.inert = true;
      modal.style.display = 'none';
      modal.innerHTML = `
        <div class="pm-modal-overlay"></div>
        <div class="pm-modal-content">
          <div class="pm-modal-header">
            <h3 id="template-save-title">Task Template</h3>
            <button class="pm-btn-icon" type="button" data-close-template-save aria-label="Close template form">${window.csIcon('close')}</button>
          </div>
          <div class="pm-modal-body">
            <div class="pm-form-group">
              <label for="template-save-name">Template name</label>
              <input type="text" class="pm-input" id="template-save-name" maxlength="60" placeholder="For example, Weekly report">
            </div>
            <div class="pm-form-group"><label for="template-priority">Default priority</label><select class="pm-select" id="template-priority"><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option><option value="urgent">Urgent</option></select></div>
            <div class="pm-form-group"><label>Menus shown when creating a task</label><div class="cs-template-fields"><label class="cs-template-field"><input type="checkbox" value="status">Status</label><label class="cs-template-field"><input type="checkbox" value="assignee">Assignee</label><label class="cs-template-field"><input type="checkbox" value="space">Space</label><label class="cs-template-field"><input type="checkbox" value="project">Project</label><label class="cs-template-field"><input type="checkbox" value="description">Description</label><label class="cs-template-field"><input type="checkbox" value="tags">Tags</label><label class="cs-template-field"><input type="checkbox" value="estimate">Time estimate</label></div></div>
            <div class="pm-helper-copy">Due Date and Priority are always shown. Your selected menus will appear immediately after you apply this template.</div>
            <div id="template-save-error" style="display:none;color:#dc2626;font-size:13px;margin-top:8px;"></div>
          </div>
          <div class="pm-modal-footer">
            <button class="pm-btn-ghost" type="button" id="template-save-cancel">Cancel</button>
            <button class="pm-btn-primary" type="button" id="template-save-confirm">Save Template</button>
          </div>
        </div>`;
      document.body.appendChild(modal);
    }
    const close = () => {
      modal.style.display = 'none';
      modal.setAttribute('aria-hidden', 'true');
      modal.inert = true;
    };
    modal.querySelector('[data-close-template-save]')?.addEventListener('click', close);
    modal.querySelector('.pm-modal-overlay')?.addEventListener('click', close);
    modal.querySelector('#template-save-cancel')?.addEventListener('click', close);
    const nameInput = modal.querySelector('#template-save-name');
    const error = modal.querySelector('#template-save-error');
    nameInput.value = taskId ? `${task.name || 'Task'} template` : '';
    modal.querySelector('#template-priority').value = task.priority || 'medium';
    const selectedFields = new Set((task.visibleFields || ['priority','due']).map(field => field === 'spaceId' ? 'space' : field));
    modal.querySelectorAll('.cs-template-field input').forEach(input => { input.checked = selectedFields.has(input.value); });
    error.style.display = 'none';
    modal.querySelector('#template-save-confirm').onclick = async () => {
      const name = nameInput.value.trim();
      if (!name) { error.textContent = 'Template name is required.'; error.style.display = 'block'; nameInput.focus(); return; }
      const confirmButton = modal.querySelector('#template-save-confirm');
      confirmButton.disabled = true;
      confirmButton.textContent = 'Saving...';
      error.style.display = 'none';
      const template = {
        name,
        priority: modal.querySelector('#template-priority').value || 'medium',
        visibleFields: ['priority', 'due', ...Array.from(modal.querySelectorAll('.cs-template-field input:checked')).map(input => input.value)]
      };
      const existing = this.data.settings.taskTemplates || [];
      const duplicateIndex = existing.findIndex(item => item.name.trim().toLocaleLowerCase() === name.toLocaleLowerCase());
      const next = duplicateIndex >= 0 ? existing.map((item, index) => index === duplicateIndex ? template : item) : [...existing, template].slice(-24);
      try {
        await saveSettingsMerge({ taskTemplates: next });
        this.showToast(duplicateIndex >= 0 ? 'Template updated' : 'Template saved');
        refreshTemplateControls();
        close();
      } catch (saveError) {
        this.data.settings.taskTemplates = existing;
        console.error('Template save failed:', saveError);
        error.textContent = 'Could not save this template. Please retry.';
        error.style.display = 'block';
      } finally {
        confirmButton.disabled = false;
        confirmButton.textContent = 'Save Template';
      }
    };
    modal.style.display = 'flex';
    modal.setAttribute('aria-hidden', 'false');
    modal.inert = false;
    setTimeout(() => nameInput.focus(), 0);
  };

  app.removeTemplate = async function removeTemplate(index) {
    const previous = [...(this.data.settings.taskTemplates || [])];
    if (!previous[index]) return;
    const next = [...previous];
    next.splice(index, 1);
    try {
      await saveSettingsMerge({ taskTemplates: next });
      refreshTemplateControls();
      this.showToast('Template deleted');
    } catch (removeError) {
      this.data.settings.taskTemplates = previous;
      console.error('Template deletion failed:', removeError);
      this.showToast('Could not delete template');
    }
  };

  app.removeCustomStatus = async function removeCustomStatus(index) {
    const next = [...(this.data.settings.customStatuses || [])];
    next.splice(index, 1);
    this.data.settings.customStatuses = next;
    await setDoc(doc(window.fbDb, 'clearspace_users', this.data.user.uid), { settings: this.data.settings }, { merge: true });
    renderStatusList();
  };

  const originalApplySettingsCore = app.applySettings.bind(app);
  app.applySettings = function applySettingsFeaturePack(settings, startup = false) {
    originalApplySettingsCore(settings, startup);
    setTheme();
    this.data.currentView = this.data.currentView || this.data.settings.defaultView || 'list';
  };

  const originalShowSettings = app.showSettings.bind(app);
  app.showSettings = function showSettingsFeaturePack() {
    originalShowSettings();
    injectSettingsControls();
    const templateButton = qs('#cs-save-template-btn');
    if (templateButton) {
      const hasOpenTask = Boolean(this.data.currentTaskId && this.data.tasks.some(task => task.id === this.data.currentTaskId));
      templateButton.disabled = false;
      templateButton.textContent = hasOpenTask ? 'Save current task as template' : 'Create template';
      templateButton.title = hasOpenTask ? 'Save the selected task as a reusable template' : 'Create a reusable task template';
    }
    qs('#cs-notifications-toggle') && (qs('#cs-notifications-toggle').checked = Boolean(this.data.settings.notificationsEnabled));
    renderTemplateList();
    renderStatusList();
    qs('#settings-theme') && (qs('#settings-theme').value = this.data.settings.theme || 'light');
  };

  app.saveSettings = async function saveSettingsFeaturePack() {
    if (!this.data.user) return;
    const name = qs('#settings-display-name').value.trim();
    const oldName = this.data.user.displayName || this.data.user.email?.split('@')[0] || 'User';
    const error = qs('#settings-error');
    const save = qs('#settings-save');
    error.style.display = 'none';
    error.textContent = '';
    if (!name) { error.textContent = 'Display name is required.'; error.style.display = 'block'; return; }
    const nextSettings = {
      theme: qs('#settings-theme').value,
      accent: qs('#settings-accent').value,
      density: qs('#settings-density').value,
      fontSize: qs('#settings-font-size').value,
      defaultView: qs('#settings-default-view').value,
      weekStart: qs('#settings-week-start').value,
      defaultPriority: qs('#settings-default-priority').value,
      sidebarDefault: qs('#settings-sidebar-default').value,
      savedViews: this.data.settings.savedViews || [],
      notificationsEnabled: Boolean(qs('#cs-notifications-toggle')?.checked),
      customStatuses: this.data.settings.customStatuses || [],
      taskTemplates: this.data.settings.taskTemplates || [],
      calendarWeekView: Boolean(this.data.settings.calendarWeekView),
    };
    save.disabled = true; save.textContent = 'Saving...';
    try {
      const nameChanged = name !== oldName;
      if (nameChanged) await updateProfile(this.data.user, { displayName: name });
      const assignedTasks = nameChanged
        ? this.data.tasks.filter(task => task.assigneeId === this.data.user.uid || (!task.assigneeId && task.assignee === oldName))
        : [];
      for (let index = 0; index < assignedTasks.length; index += 450) {
        const batch = writeBatch(window.fbDb);
        assignedTasks.slice(index, index + 450).forEach(task => batch.update(doc(window.fbDb, 'clearspace_tasks', task.id), { assignee: name, assigneeId: this.data.user.uid, updatedAt: serverTimestamp() }));
        await batch.commit();
      }
      assignedTasks.forEach(task => { task.assignee = name; task.assigneeId = this.data.user.uid; });
      await setDoc(doc(window.fbDb, 'clearspace_users', this.data.user.uid), { displayName: name, settings: nextSettings }, { merge: true });
      this.applySettings(nextSettings);
      this.updateProfileUI();
      this.renderContent();
      this.closeSettings();
      this.showToast('Settings saved');
    } catch (err) {
      console.error('Settings update failed:', err);
      error.textContent = 'Could not save settings. Please retry.';
      error.style.display = 'block';
    } finally {
      save.disabled = false; save.textContent = 'Save changes';
    }
  };

  app.toggleGoalMilestone = async function toggleGoalMilestone(goalId, milestoneIndex) {
    const goal = this.data.goals.find(item => item.id === goalId);
    if (!goal || !Array.isArray(goal.milestones) || !goal.milestones[milestoneIndex]) return;
    const previous = goal.milestones.map(item => ({ ...item }));
    const next = previous.map((item, index) => index === milestoneIndex ? { ...item, done: !item.done } : item);
    const progress = Math.round((next.filter(item => item.done).length / next.length) * 100);
    goal.milestones = next;
    goal.progress = progress;
    this.showGoal(goalId, { fromRoute: true });
    try {
      await updateDoc(doc(window.fbDb, 'clearspace_goals', goalId), { milestones: next, progress, updatedAt: serverTimestamp() });
      this.showToast(next[milestoneIndex].done ? 'Milestone completed' : 'Milestone reopened');
    } catch (error) {
      goal.milestones = previous;
      goal.progress = Math.round((previous.filter(item => item.done).length / previous.length) * 100);
      this.showGoal(goalId, { fromRoute: true });
      console.error('Milestone update failed:', error);
      this.showToast('Could not update the milestone');
    }
  };

  app.showGoal = function showGoalFeaturePack(goalId, options = {}) {
    const goal = this.data.goals.find(item => item.id === goalId);
    if (!goal) return;
    this.data.currentPage = 'goal';
    this.data.currentGoal = goalId;
    const milestones = Array.isArray(goal.milestones) ? goal.milestones : [];
    const progress = milestones.length ? Math.round((milestones.filter(m => m.done).length / milestones.length) * 100) : Math.max(0, Math.min(100, Number(goal.progress) || 0));
    const container = qs('#content-area');
    if (!container) return;
    container.innerHTML = `<div class="pm-dashboard pm-fade-in"><div class="pm-dashboard-card" style="grid-column:1/-1;"><div class="pm-dashboard-card-title">Goal</div><div style="font-size:26px;font-weight:700;margin:8px 0 18px;">${escapeHTML(goal.name)}</div><div class="pm-progress-bar"><div class="pm-progress-fill" id="goal-progress-fill" style="width:${progress}%"></div></div><div class="pm-stat-label" id="goal-progress-label" style="margin-top:8px;">${progress}% complete</div><div class="pm-helper-copy">${milestones.length ? 'Progress updates when you complete milestones below.' : 'Move the slider to record your progress, or add milestones for automatic progress.'}</div><input id="goal-progress-input" type="range" min="0" max="100" value="${progress}" ${milestones.length ? 'disabled aria-disabled="true"' : ''} style="width:100%;margin:22px 0 14px;" oninput="document.getElementById('goal-progress-label').textContent=this.value+'% complete';document.getElementById('goal-progress-fill').style.width=this.value+'%'" onchange="app.saveGoalProgress('${goal.id}')"><div style="display:flex;align-items:center;justify-content:space-between;gap:10px;"><span style="font-size:12px;color:#6b7280;">${milestones.length ? 'Calculated automatically' : 'Progress saves automatically'}</span><button class="pm-btn-ghost" onclick="app.deleteGoal('${goal.id}')" style="color:#dc2626;">Delete goal</button></div></div><div class="pm-dashboard-card" style="grid-column:1/-1;margin-top:12px;"><div class="pm-dashboard-card-title">Milestones</div><div style="display:grid;gap:10px;margin-top:12px;">${milestones.length ? milestones.map((m, index) => `<button type="button" class="pm-saved-view-row" onclick="app.toggleGoalMilestone('${goal.id}',${index})" aria-pressed="${Boolean(m.done)}" style="width:100%;display:flex;align-items:center;gap:10px;text-align:left;cursor:pointer;"><span class="pm-task-checkbox ${m.done ? 'checked' : ''}" aria-hidden="true">${m.done ? '&#10003;' : ''}</span><span style="${m.done ? 'text-decoration:line-through;color:#6b7280;' : ''}">${escapeHTML(m.name)}</span></button>`).join('') : '<div class="cs-mini-note">No milestones yet.</div>'}</div><div class="cs-row" style="margin-top:12px;"><button class="pm-btn-ghost" type="button" id="cs-add-milestone-goal">Add milestone</button></div></div></div>`;
    qs('#cs-add-milestone-goal')?.addEventListener('click', () => this.openEntityModal('milestone', goal));
    this.updatePageContext();
    if (!options.fromRoute) this.setRoute(`/goals/${encodeURIComponent(goalId)}`);
  };

  const originalShowTimeTracking = app.showTimeTracking.bind(app);
  app.showTimeTracking = function showTimeTrackingFeaturePack(options = {}) {
    const result = originalShowTimeTracking(options);
    setTimeout(decorateTimeView, 0);
    return result;
  };

  const originalOpenTask = app.openTask.bind(app);
  app.openTask = async function openTaskFeaturePack(id) {
    await originalOpenTask(id);
    setTimeout(decorateDetailPanel, 0);
  };

  const originalSetupKeyboard = app.setupKeyboard.bind(app);
  app.setupKeyboard = function setupKeyboardFeaturePack() {
    originalSetupKeyboard();
  };

  const originalCreateTask = app.createTask.bind(app);
  app.createTask = function createTaskFeaturePack() {
    originalCreateTask();
    setTimeout(() => {
      injectCreateControls();
      const rec = qs('#new-task-recurring');
      if (rec && !rec.dataset.csBound) {
        rec.dataset.csBound = '1';
      }
    }, 0);
  };

  const originalLoadTasks = app.loadTasks?.bind(app);
  if (originalLoadTasks) {
    app.loadTasks = async function loadTasksFeaturePack() {
      const result = await originalLoadTasks();
      setTimeout(() => { notifyDueTasks(); ensureTaskListBindings(); }, 0);
      return result;
    };
  }

  const originalApplySettings = app.applySettings?.bind(app);
  app.applySettings = function applySettingsFeaturePack2(settings, startup = false) {
    if (originalApplySettings) originalApplySettings(settings, startup);
    setTheme();
  };

  const originalCloseModal = app.closeModal.bind(app);
  app.closeModal = function closeModalFeaturePack() {
    return originalCloseModal();
  };

  const originalRenderContent2 = app.renderContent.bind(app);
  app.renderContent = function renderContentFeaturePack2() {
    const out = originalRenderContent2();
    setTimeout(() => {
      injectTopbarControls();
      injectCreateControls();
      injectSettingsControls();
      ensureTaskListBindings();
      decorateDetailPanel();
      decorateGoalView();
      decorateTimeView();
      injectCalendarTools();
      notifyDueTasks();
    }, 0);
    return out;
  };


  const originalToggleTask2 = app.toggleTask.bind(app);
  app.toggleTask = async function toggleTaskFeaturePack2(id) {
    const task = this.data.tasks.find(t => t.id === id);
    const before = task ? task.status : null;
    await originalToggleTask2(id);
    const recurrence = task?.recurrence || task?.recurring;
    if (task && before !== 'done' && task.status === 'done' && recurrence && normalizeRecurrence(recurrence).frequency !== 'none') {
      const nextDue = recurringNextDate(task.due, recurrence);
      if (!nextDue) { this.showToast('Recurring series completed'); return; }
      const payload = {
        ...task,
        status: 'todo',
        due: nextDue,
        recurrenceOccurrence: (Number(task.recurrenceOccurrence) || 1) + 1,
        sortOrder: Date.now(),
        completedAt: null,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        workspaceId: app.data.currentWorkspaceId || app.data.workspace?.id || app.data.user?.uid,
      };
      delete payload.id;
      delete payload.googleCalendarEventId;
      delete payload.calendarSyncedAt;
      await addDoc(collection(window.fbDb, 'clearspace_tasks'), payload);
      this.showToast('Recurring task rolled over');
    }
  };

  if (!app.__featureBooted) {
    app.__featureBooted = true;
    setTheme();
    injectTopbarControls();
    injectShortcutsListener();
  }
  };
  if (window.app) boot(); else document.addEventListener('DOMContentLoaded', boot, { once: true });
})();




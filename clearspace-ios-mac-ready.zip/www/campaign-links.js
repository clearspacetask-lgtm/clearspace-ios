(() => {
  const incoming = new URLSearchParams(window.location.search);
  const campaignKeys = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term'];
  if (!campaignKeys.some((key) => incoming.has(key))) return;

  document.querySelectorAll('a[href^="/signup"]').forEach((link) => {
    const target = new URL(link.getAttribute('href'), window.location.origin);
    const originalContent = target.searchParams.get('utm_content');
    if (originalContent) target.searchParams.set('landing_cta', originalContent);
    campaignKeys.forEach((key) => {
      const value = incoming.get(key);
      if (value) target.searchParams.set(key, value);
    });
    link.setAttribute('href', `${target.pathname}${target.search}`);
  });
})();

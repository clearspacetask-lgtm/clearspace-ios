import { collection, doc, setDoc, getDoc, getDocs, addDoc, updateDoc, deleteDoc, onSnapshot, query, where, serverTimestamp, arrayUnion, arrayRemove, writeBatch } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { signOut } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

const app = window.app;
if (!app) throw new Error('ClearSpace app was not loaded before teams-addon.js');

Object.assign(app.data, {
  workspace: null,
  currentWorkspaceId: '',
  workspaces: [],
  members: [],
  allWorkspaceSpaces: [],
  allWorkspaceTasks: [],
  workspaceBilling: null,
  accountBilling: null,
  unsubAccountBilling: null,
  inviteInbox: [],
  blockedEmails: [],
  pendingOwnerTransferId: '',
  unsubWorkspace: null,
  unsubWorkspaceMemberships: null,
  unsubMembers: null,
  unsubInviteInbox: null,
  unsubBlockedEmails: null,
  inviteSaving: false,
  acceptingInviteId: '',
  joinedSpaceId: '',
  managedSpaceId: '',
});

const inviteFromLink = new URLSearchParams(location.search).get('invite');
if (inviteFromLink) sessionStorage.setItem('clearspacePendingInvite', inviteFromLink);

const memberName = (member) => member?.displayName || member?.email?.split('@')[0] || 'Member';
const memberCanViewSpace = (member, spaceId) => Boolean(member && (member.role === 'owner' || (member.spaceIds || []).includes(spaceId) || (member.viewSpaceIds || []).includes(spaceId) || (member.editSpaceIds || []).includes(spaceId)));
const memberCanEditSpace = (member, spaceId) => Boolean(member && (member.role === 'owner' || (member.spaceIds || []).includes(spaceId) || (member.editSpaceIds || []).includes(spaceId)));
const workspaceSeatLimit = () => (app.isPro() ? 50 : 4);
const workspaceName = () => app.data.workspace?.name || 'Workspace';
const currentMember = () => app.data.members.find((member) => member.userId === app.data.user?.uid) || null;
const workspaceIsOwner = () => app.data.workspace?.ownerId === app.data.user?.uid;
const workspaceIsManager = () => ['owner', 'admin'].includes(currentMember()?.role || '');
const spaceIsManager = (space) => Boolean(space && app.data.user && (space.managerId ? space.managerId === app.data.user.uid : space.userId ? space.userId === app.data.user.uid : workspaceIsManager()));
const normalizedEmail = (email = '') => String(email).trim().toLowerCase();
const blockedEmailDoc = (workspaceId, emailLower) => doc(window.fbDb, 'clearspace_workspaces', workspaceId, 'blocked_emails', emailLower);

function isCurrentUserBlocked() {
  const emailLower = normalizedEmail(app.data.user?.email || '');
  if (!emailLower) return false;
  return (app.data.blockedEmails || []).some((item) => item.emailLower === emailLower);
}

function enforceWorkspaceAccess() {
  if (!app.data.user || !app.data.currentWorkspaceId) return;
  const ownerOverride = workspaceIsOwner() || currentMember()?.role === 'owner';
  if (isCurrentUserBlocked() && !ownerOverride) {
    alert('Your email has been blocked from this workspace.');
    signOut(window.fbAuth).catch((error) => console.error('Sign-out after block failed:', error));
    return true;
  }
  return false;
}

function assigneeOptionsHTML(selected = 'unassigned', spaceId = '') {
  if (selected === 'myself') selected = app.data.user?.uid || 'unassigned';
  const seen = new Set();
  const options = ['<option value="unassigned">Unassigned</option>'];
  app.data.members.filter((member) => member.status !== 'removed' && (!spaceId || memberCanEditSpace(member, spaceId))).forEach((member) => {
    if (!member.userId || seen.has(member.userId)) return;
    seen.add(member.userId);
    const safeLabel = app.escapeHTML(memberName(member));
    options.push(`<option value="${member.userId}" ${selected === member.userId ? 'selected' : ''}>${safeLabel}</option>`);
  });
  if (app.data.user?.uid && !seen.has(app.data.user.uid)) {
    options.push(`<option value="${app.data.user.uid}" ${selected === app.data.user.uid ? 'selected' : ''}>${app.escapeHTML(app.data.user.displayName || app.data.user.email?.split('@')[0] || 'Me')}</option>`);
  }
  return options.join('');
}

function visibleSpaceIds() {
  const member = currentMember();
  if (!app.data.workspace || !member) return null;
  if (workspaceIsOwner() || member?.role === 'owner') return null;
  return new Set([...(member?.spaceIds || []), ...(member?.viewSpaceIds || []), ...(member?.editSpaceIds || [])]);
}

function applyWorkspaceVisibility() {
  const allowed = visibleSpaceIds();
  const defaults = app.data.spaces.filter((space) => !space.custom);
  const custom = (app.data.allWorkspaceSpaces || []).filter((space) => allowed === null || allowed.has(space.id) || space.managerId === app.data.user?.uid || (!space.managerId && space.userId === app.data.user?.uid));
  app.data.spaces = [...defaults, ...custom];
  app.data.tasks = (app.data.allWorkspaceTasks || []).filter((task) => allowed === null || !task.spaceId ? allowed === null || task.assigneeId === app.data.user?.uid : allowed.has(task.spaceId));
  app.renderSpaces();
  app.renderContent();
  app.updateNavigationCounts();
}

function syncCollaboratorUI() {
  const filter = document.getElementById('assignee-filter');
  if (filter) {
    const current = app.data.filterAssignee || 'all';
    const memberOptions = app.data.members
      .filter((member) => member.status !== 'removed')
      .map((member) => `<option value="${app.escapeHTML(memberName(member))}">${app.escapeHTML(memberName(member))}</option>`)
      .join('');
    filter.innerHTML = `<option value="all">Anyone</option><option value="myself">Myself</option>${memberOptions}`;
    filter.value = current;
  }
  const seatBadge = document.getElementById('workspace-seat-badge');
  if (seatBadge) seatBadge.textContent = `${app.data.members.filter((member) => member.status !== 'removed').length} of ${workspaceSeatLimit()} seats`;
  const workspaceLabel = document.getElementById('profile-workspace-name');
  if (workspaceLabel) workspaceLabel.textContent = workspaceName();
  const breadcrumbLabel = document.getElementById('breadcrumb-home-label');
  if (breadcrumbLabel) breadcrumbLabel.textContent = workspaceName();
  renderWorkspaceSwitcher();
  renderWorkspaceSharing();
}

function renderWorkspaceSharing() {
  const mount = document.getElementById('workspace-sharing-members');
  if (!mount) return;
  const canManage = workspaceIsManager();
  const members = (app.data.members || []).filter((member) => member.status !== 'removed');
  mount.innerHTML = members.map((member) => {
    const role = ['owner', 'admin'].includes(member.role) ? member.role : 'member';
    const canChange = workspaceIsOwner() && member.userId !== app.data.user?.uid;
    return `<div class="pm-saved-view-row" style="display:flex;align-items:center;justify-content:space-between;gap:12px;"><div style="min-width:0;"><div style="font-weight:700;overflow:hidden;text-overflow:ellipsis;">${app.escapeHTML(memberName(member))}</div><div style="font-size:12px;color:#6b7280;overflow:hidden;text-overflow:ellipsis;">${app.escapeHTML(member.email || '')}</div></div>${canChange ? `<select class="pm-input" aria-label="Role for ${app.escapeHTML(memberName(member))}" onchange="app.changeWorkspaceRole('${member.userId}',this.value)" style="width:auto;min-width:108px;padding:7px 30px 7px 10px;"><option value="member" ${role === 'member' ? 'selected' : ''}>User</option><option value="admin" ${role === 'admin' ? 'selected' : ''}>Admin</option><option value="owner">Owner</option></select>` : `<span class="pm-plan-badge">${role === 'owner' ? 'Owner' : role === 'admin' ? 'Admin' : 'User'}</span>`}</div>`;
  }).join('') || '<div style="font-size:13px;color:#6b7280;">No workspace members yet.</div>';
  document.getElementById('workspace-sharing-invite-wrap')?.toggleAttribute('hidden', !canManage);
  const title = document.getElementById('workspace-sharing-name');
  if (title) title.textContent = workspaceName();
  const danger = document.getElementById('workspace-delete-settings');
  if (danger) danger.hidden = !workspaceIsOwner() || app.data.currentWorkspaceId === app.data.user?.uid;
}

function renderWorkspaceSwitcher() {
  const label = document.getElementById('workspace-switcher-label');
  const menu = document.getElementById('workspace-switcher-menu');
  if (label) label.textContent = workspaceName();
  if (!menu) return;
  menu.innerHTML = `${(app.data.workspaces || []).map((workspace) => `
    <button type="button" class="pm-profile-menu-item ${workspace.id === app.data.currentWorkspaceId ? 'active' : ''}" onclick="app.switchWorkspace('${workspace.id}')" role="menuitem" style="justify-content:space-between;">
      <span style="display:flex;align-items:center;gap:9px;min-width:0;"><span data-cs-icon="folder"></span><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${app.escapeHTML(workspace.name || 'Workspace')}</span></span>
      ${workspace.id === app.data.currentWorkspaceId ? '<span data-cs-icon="check"></span>' : ''}
    </button>`).join('')}
    <div style="height:1px;background:#eef0f3;margin:6px 0;"></div>
    <button type="button" class="pm-profile-menu-item" onclick="app.openCreateWorkspace()" role="menuitem"><span data-cs-icon="plus"></span> Create workspace</button>`;
  window.csHydrateIcons?.(menu);
}

function injectTeamsUI() {
  if (!document.getElementById('workspace-switcher')) {
    document.querySelector('.pm-sidebar nav')?.insertAdjacentHTML('beforebegin', `
      <div id="workspace-switcher" style="position:relative;margin:10px 10px 8px;">
        <button type="button" class="pm-btn-ghost" onclick="app.toggleWorkspaceSwitcher(event)" aria-haspopup="menu" aria-expanded="false" id="workspace-switcher-button" style="width:100%;justify-content:space-between;min-width:0;padding:10px 11px;">
          <span style="display:flex;align-items:center;gap:9px;min-width:0;"><span data-cs-icon="folder"></span><span id="workspace-switcher-label" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">Workspace</span></span><span data-cs-icon="chevronDown"></span>
        </button>
        <div id="workspace-switcher-menu" class="pm-profile-dropdown" role="menu" style="left:0;right:auto;top:calc(100% + 6px);width:min(280px,calc(100vw - 24px));z-index:120;"></div>
      </div>`);
  }
  if (!document.getElementById('create-workspace-modal')) {
    document.getElementById('settings-modal')?.insertAdjacentHTML('beforebegin', `
      <div class="pm-modal" id="create-workspace-modal" role="dialog" aria-modal="true" aria-labelledby="create-workspace-title" aria-hidden="true" inert style="display:none">
        <div class="pm-modal-overlay" onclick="app.closeCreateWorkspace()"></div>
        <div class="pm-modal-content" style="max-width:500px;">
          <div class="pm-modal-header"><div><h3 id="create-workspace-title" style="margin:0;">Create a workspace</h3><div style="font-size:13px;color:#6b7280;margin-top:4px;">A separate home for its tasks, Spaces, teammates, and plan.</div></div><button class="pm-btn-icon" onclick="app.closeCreateWorkspace()" aria-label="Close">${window.csIcon('close')}</button></div>
          <form class="pm-modal-body" onsubmit="event.preventDefault();app.createWorkspace()">
            <label for="new-workspace-name" style="display:block;font-size:13px;font-weight:700;margin-bottom:7px;">Workspace name</label>
            <input id="new-workspace-name" class="pm-input" maxlength="80" autocomplete="off" placeholder="For example, Client work" required>
            <div id="create-workspace-status" role="status" style="min-height:20px;margin-top:8px;color:#b91c1c;font-size:13px;"></div>
            <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:18px;"><button type="button" class="pm-btn-ghost" onclick="app.closeCreateWorkspace()">Cancel</button><button type="submit" class="pm-btn-primary" id="create-workspace-submit">Create workspace</button></div>
          </form>
        </div>
      </div>`);
  }
  if (!document.getElementById('workspace-sharing-settings')) {
    document.getElementById('settings-error')?.insertAdjacentHTML('beforebegin', `
      <section id="workspace-sharing-settings" style="margin-top:18px;padding:14px;border:1px solid var(--pm-border,#e5e7eb);border-radius:14px;background:var(--pm-surface-soft,#f8fafc);">
        <div style="font-weight:750;font-size:14px;">Workspace sharing</div>
        <div id="workspace-sharing-name" style="font-size:12px;color:#6b7280;margin-top:3px;">Workspace</div>
        <p style="font-size:12px;line-height:1.5;color:#6b7280;margin:8px 0 12px;">Invite people to this workspace first. Then open a Space’s settings to choose who can view or edit it.</p>
        <div id="workspace-sharing-invite-wrap" style="display:flex;flex-wrap:wrap;gap:8px;"><input id="workspace-invite-email" type="email" class="pm-input" style="flex:1 1 220px;" placeholder="teammate@example.com" autocomplete="email"><select id="workspace-invite-role" class="pm-input" aria-label="Workspace role" style="flex:0 1 130px;"><option value="member">User</option><option value="admin">Admin</option></select><button type="button" class="pm-btn-primary" id="workspace-invite-button" onclick="app.sendWholeWorkspaceInvite()">Invite</button></div>
        <div id="workspace-invite-status" role="status" style="min-height:18px;margin-top:6px;font-size:12px;color:#6b7280;"></div>
        <div id="workspace-sharing-members" style="display:grid;gap:8px;margin-top:10px;"></div>
      </section>`);
  }
  if (!document.getElementById('workspace-delete-settings')) {
    document.getElementById('settings-error')?.insertAdjacentHTML('beforebegin', `
      <section id="workspace-delete-settings" hidden style="margin-top:18px;padding:14px;border:1px solid #fecaca;border-radius:14px;background:#fff7f7;">
        <div style="font-weight:750;font-size:14px;color:#991b1b;">Delete workspace</div>
        <p style="font-size:12px;line-height:1.5;color:#7f1d1d;margin:8px 0 12px;">Permanently delete this workspace and everything stored inside it. This cannot be undone.</p>
        <button type="button" class="pm-btn-ghost" onclick="app.openDeleteWorkspace()" style="border-color:#ef4444;color:#b91c1c;">Delete workspace</button>
      </section>`);
  }
  if (!document.getElementById('delete-workspace-modal')) {
    document.getElementById('settings-modal')?.insertAdjacentHTML('beforebegin', `
      <div class="pm-modal" id="delete-workspace-modal" role="dialog" aria-modal="true" aria-labelledby="delete-workspace-title" aria-hidden="true" inert style="display:none">
        <div class="pm-modal-overlay" onclick="app.closeDeleteWorkspace()"></div>
        <div class="pm-modal-content" style="max-width:520px;">
          <div class="pm-modal-header"><div><h3 id="delete-workspace-title" style="margin:0;color:#991b1b;">Delete workspace</h3><div style="font-size:13px;color:#6b7280;margin-top:4px;">This permanently removes its tasks, Spaces, goals, invitations, and members.</div></div><button class="pm-btn-icon" onclick="app.closeDeleteWorkspace()" aria-label="Close">${window.csIcon('close')}</button></div>
          <div class="pm-modal-body"><p style="margin:0 0 12px;">Type <strong id="delete-workspace-confirm-name"></strong> to confirm.</p><input id="delete-workspace-name-input" class="pm-input" autocomplete="off" aria-label="Workspace name confirmation"><div id="delete-workspace-status" role="status" style="min-height:20px;margin-top:8px;color:#b91c1c;font-size:13px;"></div><div style="display:flex;justify-content:flex-end;gap:10px;margin-top:18px;"><button type="button" class="pm-btn-ghost" onclick="app.closeDeleteWorkspace()">Cancel</button><button type="button" class="pm-btn-primary" id="delete-workspace-submit" onclick="app.deleteCurrentWorkspace()" style="background:#b91c1c;">Delete permanently</button></div></div>
        </div>
      </div>`);
  }
  if (!document.getElementById('transfer-owner-modal')) {
    document.getElementById('settings-modal')?.insertAdjacentHTML('beforebegin', `
      <div class="pm-modal" id="transfer-owner-modal" role="dialog" aria-modal="true" aria-labelledby="transfer-owner-title" aria-hidden="true" inert style="display:none">
        <div class="pm-modal-overlay" onclick="app.closeOwnerTransfer()"></div><div class="pm-modal-content" style="max-width:500px;"><div class="pm-modal-header"><div><h3 id="transfer-owner-title" style="margin:0;">Transfer workspace ownership</h3><div style="font-size:13px;color:#6b7280;margin-top:4px;">The new owner will control roles, workspace deletion, and billing.</div></div><button class="pm-btn-icon" onclick="app.closeOwnerTransfer()" aria-label="Close">${window.csIcon('close')}</button></div><div class="pm-modal-body"><p id="transfer-owner-copy" style="margin:0;"></p><div style="display:flex;justify-content:flex-end;gap:10px;margin-top:20px;"><button class="pm-btn-ghost" onclick="app.closeOwnerTransfer()">Cancel</button><button class="pm-btn-primary" onclick="app.confirmOwnerTransfer()">Transfer ownership</button></div></div></div>
      </div>`);
  }
  if (!document.getElementById('team-modal')) {
    const settingsModal = document.getElementById('settings-modal');
    settingsModal?.insertAdjacentHTML('beforebegin', `
      <div class="pm-modal" id="team-modal" role="dialog" aria-modal="true" aria-labelledby="team-title" aria-hidden="true" inert style="display:none">
        <div class="pm-modal-overlay" onclick="app.closeTeamSettings()"></div>
        <div class="pm-modal-content" style="max-width:760px;">
          <div class="pm-modal-header">
            <div>
              <h3 id="team-title" style="margin:0;">Manage Space</h3>
              <div style="font-size:13px;color:#6b7280;margin-top:4px;">Rename this Space and choose who can collaborate in it.</div>
            </div>
            <button class="pm-btn-icon" onclick="app.closeTeamSettings()" aria-label="Close team settings">${window.csIcon('close')}</button>
          </div>
          <div class="pm-modal-body"><div id="team-modal-body"></div></div>
        </div>
      </div>`);
  }

  if (!document.getElementById('workspace-seat-badge')) {
    const header = document.querySelector('#profile-dropdown-name')?.parentElement;
    header?.insertAdjacentHTML('beforeend', '<div class="pm-plan-summary" style="margin-top:8px;display:flex;align-items:center;gap:7px;flex-wrap:wrap;"><span class="pm-plan-badge" id="workspace-seat-badge">0 of 4 seats</span></div><div class="pm-profile-dropdown-email" id="profile-workspace-name" style="margin-top:8px;">Workspace</div>');
  }

  document.getElementById('team-menu-item')?.remove();

  const pricingStatus = document.getElementById('billing-status');
  if (pricingStatus && !document.getElementById('billing-seat-note')) {
    pricingStatus.insertAdjacentHTML('afterend', '<div class="pm-billing-status" id="billing-seat-note" style="margin-top:10px;">Free includes up to 4 workspace members total. ClearSpace Pro unlocks 5+ seats and larger shared teams for $15/month.</div>');
  }
}

async function ensureWorkspace(userData = null) {
  if (!app.data.user) return;
  const profileRef = doc(window.fbDb, 'clearspace_users', app.data.user.uid);
  const profileData = userData || {};
  const storedWorkspaceId = localStorage.getItem(`clearspace_workspace_${app.data.user.uid}`) || '';
  const knownWorkspaceIds = Array.isArray(profileData.workspaceIds) ? profileData.workspaceIds : [];
  const workspaceId = (storedWorkspaceId && knownWorkspaceIds.includes(storedWorkspaceId) ? storedWorkspaceId : '') || profileData.currentWorkspaceId || profileData.workspaceId || app.data.user.uid;
  const name = app.data.user.displayName || profileData.displayName || app.data.user.email?.split('@')[0] || 'Workspace';
  const resolvedWorkspaceName = profileData.workspaceName || `${name}'s Workspace`;
  const workspaceRef = doc(window.fbDb, 'clearspace_workspaces', workspaceId);
  const memberRef = doc(window.fbDb, 'clearspace_workspaces', workspaceId, 'members', app.data.user.uid);
  const isPersonalWorkspace = workspaceId === app.data.user.uid;

  if (isPersonalWorkspace) {
    await setDoc(workspaceRef, {
      name: resolvedWorkspaceName,
      ownerId: app.data.user.uid,
      plan: app.isPro() ? 'pro' : 'free',
      seatLimit: workspaceSeatLimit(),
      updatedAt: serverTimestamp(),
    }, { merge: true });
  }

  await setDoc(memberRef, {
    workspaceId,
    userId: app.data.user.uid,
    email: app.data.user.email || '',
    displayName: name,
    role: isPersonalWorkspace ? 'owner' : (profileData.role || 'member'),
    status: 'active',
    joinedAt: serverTimestamp(),
  }, { merge: true });

  await setDoc(profileRef, { workspaceId, currentWorkspaceId: workspaceId, workspaceIds: arrayUnion(workspaceId), workspaceName: resolvedWorkspaceName, updatedAt: serverTimestamp() }, { merge: true });
  app.data.currentWorkspaceId = workspaceId;
  localStorage.setItem(`clearspace_workspace_${app.data.user.uid}`, workspaceId);
}

app.ensureWorkspace = ensureWorkspace;

async function migrateLegacyWorkspaceData() {
  if (!app.data.user || !app.data.currentWorkspaceId) return;
  if (app.data.currentWorkspaceId !== app.data.user.uid) return;
  for (const collectionName of ['clearspace_tasks', 'clearspace_spaces', 'clearspace_goals', 'clearspace_projects']) {
    try {
      const snap = await getDocs(query(collection(window.fbDb, collectionName), where('userId', '==', app.data.user.uid)));
      for (const row of snap.docs) {
        if (!row.data().workspaceId) {
          await updateDoc(row.ref, {
            workspaceId: app.data.currentWorkspaceId,
            ownerId: row.data().ownerId || app.data.user.uid,
            updatedAt: serverTimestamp(),
          });
        }
      }
    } catch (error) {
      console.warn(`Legacy workspace migration skipped for ${collectionName}:`, error);
    }
  }
}

function renderTeamPanel() {
  const mount = document.getElementById('team-modal-body');
  if (!mount) return;
  const space = app.data.spaces.find((item) => item.id === app.data.managedSpaceId);
  if (!space) { mount.innerHTML = '<div class="pm-customize-section">Select a Space to manage.</div>'; return; }
  const activeMembers = app.data.members.filter((member) => member.status !== 'removed' && memberCanViewSpace(member, space.id));
  const canManage = spaceIsManager(space);
  const pendingForSpace = (app.data.inviteInbox || []).filter((invite) => invite.spaceId === space.id);
  document.getElementById('team-title').textContent = `Manage ${space.name}`;
  mount.innerHTML = `
    <div style="display:grid;gap:18px;">
      <section class="pm-customize-section">
        <h3 style="margin:0 0 8px;">Space details</h3>
        <div style="display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px;"><input id="managed-space-name" class="pm-input" maxlength="80" value="${app.escapeHTML(space.name)}" aria-label="Space name"><button class="pm-btn-ghost" onclick="app.renameManagedSpace()">Save name</button></div>
        <p style="margin:10px 0 0;color:#6b7280;font-size:13px;">${activeMembers.length} teammate${activeMembers.length === 1 ? '' : 's'} can work in this Space.</p>
      </section>
      ${canManage ? `
      <section class="pm-customize-section">
        <h3 style="margin:0 0 6px;">Invite teammates</h3>
        <p style="margin:0 0 12px;color:#6b7280;font-size:13px;">They’ll receive an email link and an invitation in their ClearSpace Inbox.</p>
        <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:end;">
          <div><label class="pm-sr-only" for="team-email">Email</label><input id="team-email" type="email" class="pm-input" placeholder="teammate@example.com" autocomplete="email"></div>
          <div><label class="pm-sr-only" for="team-role">Workspace role</label><select id="team-role" class="pm-input" aria-label="Workspace role"><option value="member">User</option>${workspaceIsOwner() ? '<option value="admin">Admin</option>' : ''}</select></div>
          <button class="pm-btn-primary" id="team-send-invite" onclick="app.sendWorkspaceInvite()">Send invite</button>
        </div>
        <div id="team-invite-status" role="status" style="margin-top:8px;color:#6b7280;font-size:13px;">${app.isPro() ? 'Team invitations are included in your plan.' : 'Free supports up to 4 workspace members. Upgrade for larger teams.'}</div>
      </section>` : ''}
      <section class="pm-customize-section">
        <h3 style="margin:0 0 6px;">Space access</h3>
        <p style="margin:0 0 12px;color:#6b7280;font-size:13px;">Choose which workspace members can see this Space and which can make changes.</p>
        <div style="display:grid;gap:10px;">
          ${app.data.members.filter((member) => member.status !== 'removed').map((member) => { const owner = member.role === 'owner'; const canView = memberCanViewSpace(member, space.id); const canEdit = memberCanEditSpace(member, space.id); return `<div class="pm-saved-view-row" style="display:grid;grid-template-columns:minmax(0,1fr) auto auto;gap:14px;align-items:center;"><div style="min-width:0;"><div style="font-weight:600;overflow:hidden;text-overflow:ellipsis;">${app.escapeHTML(memberName(member))}</div><div style="font-size:12px;color:#6b7280;overflow:hidden;text-overflow:ellipsis;">${app.escapeHTML(member.email || '')}</div></div><label style="display:flex;align-items:center;gap:6px;font-size:12px;font-weight:650;"><input type="checkbox" ${canView ? 'checked' : ''} ${!canManage || owner ? 'disabled' : ''} onchange="app.setSpacePermission('${member.userId}','view',this.checked)"> View</label><label style="display:flex;align-items:center;gap:6px;font-size:12px;font-weight:650;"><input type="checkbox" ${canEdit ? 'checked' : ''} ${!canManage || owner ? 'disabled' : ''} onchange="app.setSpacePermission('${member.userId}','edit',this.checked)"> Edit</label></div>`; }).join('') || '<div style="font-size:13px;color:#6b7280;">Invite someone to the workspace before assigning Space access.</div>'}
        </div>
      </section>
      ${pendingForSpace.length ? `<div style="font-size:12px;color:#6b7280;">${pendingForSpace.length} pending invitation${pendingForSpace.length === 1 ? '' : 's'}.</div>` : ''}
      ${canManage ? `<section class="pm-customize-section" style="border-color:#fecaca;background:#fff7f7;">
        <h3 style="margin:0 0 6px;color:#991b1b;">Delete Space</h3>
        <p style="margin:0 0 12px;color:#7f1d1d;font-size:13px;line-height:1.5;">Delete this Space permanently. Its tasks will be kept and moved to No Space.</p>
        <button type="button" class="pm-btn-ghost" id="delete-managed-space" onclick="app.deleteManagedSpace()" style="border-color:#ef4444;color:#b91c1c;">Delete Space</button>
      </section>` : ''}
    </div>`;
}

function subscribeWorkspace() {
  if (!app.data.user || !app.data.currentWorkspaceId) return;
  app.data.unsubWorkspace?.();
  app.data.unsubMembers?.();
  app.data.unsubInviteInbox?.();
  app.data.unsubBlockedEmails?.();
  app.data.unsubWorkspace = null;
  app.data.unsubMembers = null;
  app.data.unsubInviteInbox = null;
  app.data.unsubBlockedEmails = null;

  app.data.unsubWorkspace = onSnapshot(doc(window.fbDb, 'clearspace_workspaces', app.data.currentWorkspaceId), (snapshot) => {
    app.data.workspace = snapshot.exists() ? { id: snapshot.id, ...snapshot.data() } : { id: app.data.currentWorkspaceId, name: workspaceName(), ownerId: app.data.user.uid, plan: app.isPro() ? 'pro' : 'free' };
    syncCollaboratorUI();
    renderTeamPanel();
    applyWorkspaceVisibility();
    app.updatePageContext();
    enforceWorkspaceAccess();
  }, (error) => console.warn('Workspace subscription unavailable:', error));

  app.data.unsubMembers = onSnapshot(collection(window.fbDb, 'clearspace_workspaces', app.data.currentWorkspaceId, 'members'), (snapshot) => {
    app.data.members = snapshot.docs.map((row) => ({ id: row.id, ...row.data() })).sort((a, b) => memberName(a).localeCompare(memberName(b)));
    syncCollaboratorUI();
    renderTeamPanel();
    applyWorkspaceVisibility();
    enforceWorkspaceAccess();
  }, (error) => console.warn('Workspace members subscription unavailable:', error));

  if (app.data.user.email) {
    app.data.unsubInviteInbox = onSnapshot(query(collection(window.fbDb, 'clearspace_workspace_invites'), where('emailLower', '==', app.data.user.email.toLowerCase()), where('status', '==', 'pending')), (snapshot) => {
      app.data.inviteInbox = snapshot.docs.map((row) => ({ id: row.id, ...row.data() }));
      renderTeamPanel();
      if (app.data.currentPage === 'inbox') app.renderInbox();
      const requestedInvite = new URLSearchParams(location.search).get('invite') || sessionStorage.getItem('clearspacePendingInvite');
      if (requestedInvite && app.data.inviteInbox.some((invite) => invite.id === requestedInvite) && app.data.acceptingInviteId !== requestedInvite) {
        void app.acceptWorkspaceInvite(requestedInvite, { fromLink: true });
      }
    }, (error) => console.warn('Space invitation subscription unavailable:', error));
    app.data.unsubBlockedEmails = onSnapshot(collection(window.fbDb, 'clearspace_workspaces', app.data.currentWorkspaceId, 'blocked_emails'), (snapshot) => {
      app.data.blockedEmails = snapshot.docs.map((row) => ({ id: row.id, ...row.data() })).sort((a, b) => normalizedEmail(a.emailLower).localeCompare(normalizedEmail(b.emailLower)));
      renderTeamPanel();
      enforceWorkspaceAccess();
    }, (error) => console.warn('Blocked-email subscription unavailable:', error));
  }
}

async function loadAvailableWorkspaces() {
  if (!app.data.user) return;
  const profile = (await getDoc(doc(window.fbDb, 'clearspace_users', app.data.user.uid))).data() || {};
  const ids = [...new Set([...(Array.isArray(profile.workspaceIds) ? profile.workspaceIds : []), profile.workspaceId, app.data.user.uid].filter(Boolean))];
  const workspaces = [];
  for (const id of ids) {
    try {
      const [workspaceSnap, memberSnap] = await Promise.all([
        getDoc(doc(window.fbDb, 'clearspace_workspaces', id)),
        getDoc(doc(window.fbDb, 'clearspace_workspaces', id, 'members', app.data.user.uid)),
      ]);
      if (workspaceSnap.exists() && memberSnap.exists()) workspaces.push({ id, ...workspaceSnap.data(), role: memberSnap.data().role || 'member' });
    } catch (error) { console.warn('Workspace list item unavailable:', id, error); }
  }
  app.data.workspaces = workspaces.sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
  renderWorkspaceSwitcher();
}

app.toggleWorkspaceSwitcher = function toggleWorkspaceSwitcher(event) {
  event?.stopPropagation();
  const menu = document.getElementById('workspace-switcher-menu');
  const button = document.getElementById('workspace-switcher-button');
  const open = !menu?.classList.contains('open');
  menu?.classList.toggle('open', open);
  button?.setAttribute('aria-expanded', String(open));
};

app.closeWorkspaceSwitcher = function closeWorkspaceSwitcher() {
  document.getElementById('workspace-switcher-menu')?.classList.remove('open');
  document.getElementById('workspace-switcher-button')?.setAttribute('aria-expanded', 'false');
};

app.openCreateWorkspace = function openCreateWorkspace() {
  app.closeWorkspaceSwitcher();
  const modal = document.getElementById('create-workspace-modal');
  modal.style.display = 'flex'; modal.inert = false; modal.setAttribute('aria-hidden', 'false');
  const input = document.getElementById('new-workspace-name');
  input.value = ''; document.getElementById('create-workspace-status').textContent = '';
  setTimeout(() => input.focus(), 0);
};

app.closeCreateWorkspace = function closeCreateWorkspace() {
  const modal = document.getElementById('create-workspace-modal');
  if (!modal) return;
  modal.style.display = 'none'; modal.inert = true; modal.setAttribute('aria-hidden', 'true');
};

app.createWorkspace = async function createWorkspace() {
  if (!app.data.user) return;
  const input = document.getElementById('new-workspace-name');
  const status = document.getElementById('create-workspace-status');
  const submit = document.getElementById('create-workspace-submit');
  const name = String(input?.value || '').trim().replace(/\s+/g, ' ');
  if (name.length < 2) { status.textContent = 'Enter a workspace name with at least 2 characters.'; return; }
  submit.disabled = true; submit.textContent = 'Creating…'; status.textContent = '';
  try {
    const workspaceRef = doc(collection(window.fbDb, 'clearspace_workspaces'));
    await setDoc(workspaceRef, { name, ownerId: app.data.user.uid, plan: 'free', seatLimit: 4, createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
    await setDoc(doc(window.fbDb, 'clearspace_workspaces', workspaceRef.id, 'members', app.data.user.uid), { workspaceId: workspaceRef.id, userId: app.data.user.uid, email: app.data.user.email || '', displayName: app.data.user.displayName || app.data.user.email?.split('@')[0] || 'Owner', role: 'owner', status: 'active', joinedAt: serverTimestamp() });
    await setDoc(doc(window.fbDb, 'clearspace_users', app.data.user.uid), { workspaceIds: arrayUnion(workspaceRef.id), updatedAt: serverTimestamp() }, { merge: true });
    app.closeCreateWorkspace();
    await loadAvailableWorkspaces();
    await app.switchWorkspace(workspaceRef.id);
  } catch (error) {
    console.error('Create workspace failed:', error);
    status.textContent = 'Could not create that workspace. Please retry.';
  } finally { submit.disabled = false; submit.textContent = 'Create workspace'; }
};

app.switchWorkspace = async function switchWorkspace(workspaceId) {
  if (!app.data.user || !workspaceId || workspaceId === app.data.currentWorkspaceId) { app.closeWorkspaceSwitcher(); return; }
  app.closeWorkspaceSwitcher();
  try {
    const member = await getDoc(doc(window.fbDb, 'clearspace_workspaces', workspaceId, 'members', app.data.user.uid));
    if (!member.exists()) throw new Error('Membership not found');
    app.data.currentWorkspaceId = workspaceId;
    localStorage.setItem(`clearspace_workspace_${app.data.user.uid}`, workspaceId);
    await setDoc(doc(window.fbDb, 'clearspace_users', app.data.user.uid), { workspaceId, currentWorkspaceId: workspaceId, workspaceIds: arrayUnion(workspaceId), updatedAt: serverTimestamp() }, { merge: true });
    app.data.currentSpaceId = null; app.data.currentGoal = null; app.data.currentTaskId = null;
    app.data.tasks = []; app.data.spaces = []; app.data.goals = []; app.data.members = [];
    app.subscribeTasks(); app.subscribeSpaces(); app.subscribeGoals(); app.subscribeBilling();
    app.navigate('home');
    await loadAvailableWorkspaces();
    app.showToast?.(`Switched to ${(app.data.workspaces.find((item) => item.id === workspaceId)?.name || 'workspace')}.`);
  } catch (error) { console.error('Workspace switch failed:', error); alert('Could not open that workspace. Your access may have changed.'); }
};

app.openDeleteWorkspace = function openDeleteWorkspace() {
  if (!workspaceIsOwner() || app.data.currentWorkspaceId === app.data.user?.uid) return;
  app.closeSettings();
  const modal = document.getElementById('delete-workspace-modal');
  document.getElementById('delete-workspace-confirm-name').textContent = workspaceName();
  document.getElementById('delete-workspace-name-input').value = '';
  document.getElementById('delete-workspace-status').textContent = '';
  modal.inert = false; modal.setAttribute('aria-hidden', 'false'); modal.style.display = 'flex';
  setTimeout(() => document.getElementById('delete-workspace-name-input')?.focus(), 50);
};

app.closeDeleteWorkspace = function closeDeleteWorkspace() {
  const modal = document.getElementById('delete-workspace-modal');
  if (!modal) return;
  modal.style.display = 'none'; modal.inert = true; modal.setAttribute('aria-hidden', 'true');
};

async function deleteDocumentRefs(refs) {
  for (let index = 0; index < refs.length; index += 400) {
    const batch = writeBatch(window.fbDb);
    refs.slice(index, index + 400).forEach((ref) => batch.delete(ref));
    await batch.commit();
  }
}

app.deleteCurrentWorkspace = async function deleteCurrentWorkspace() {
  const workspaceId = app.data.currentWorkspaceId;
  const name = workspaceName();
  const status = document.getElementById('delete-workspace-status');
  const submit = document.getElementById('delete-workspace-submit');
  const confirmation = String(document.getElementById('delete-workspace-name-input')?.value || '').trim();
  if (!workspaceIsOwner() || !workspaceId || workspaceId === app.data.user?.uid) return;
  if (confirmation !== name) { status.textContent = `Type “${name}” exactly to continue.`; return; }
  if (app.isPro()) { status.textContent = 'Cancel this workspace’s Pro subscription from Plans & billing before deleting it.'; return; }
  submit.disabled = true; submit.textContent = 'Deleting…'; status.textContent = '';
  try {
    const topLevelCollections = ['clearspace_tasks', 'clearspace_spaces', 'clearspace_goals', 'clearspace_projects', 'clearspace_workspace_invites'];
    for (const collectionName of topLevelCollections) {
      const snapshot = await getDocs(query(collection(window.fbDb, collectionName), where('workspaceId', '==', workspaceId)));
      await deleteDocumentRefs(snapshot.docs.map((item) => item.ref));
    }
    const blockedSnapshot = await getDocs(collection(window.fbDb, 'clearspace_workspaces', workspaceId, 'blocked_emails'));
    const membersSnapshot = await getDocs(collection(window.fbDb, 'clearspace_workspaces', workspaceId, 'members'));
    await deleteDoc(doc(window.fbDb, 'clearspace_workspaces', workspaceId));
    await deleteDocumentRefs(blockedSnapshot.docs.map((item) => item.ref));
    const memberRefs = membersSnapshot.docs.map((item) => item.ref).sort((left, right) => left.id === app.data.user.uid ? 1 : right.id === app.data.user.uid ? -1 : 0);
    await deleteDocumentRefs(memberRefs);
    await setDoc(doc(window.fbDb, 'clearspace_users', app.data.user.uid), {
      workspaceIds: arrayRemove(workspaceId),
      workspaceId: app.data.user.uid,
      currentWorkspaceId: app.data.user.uid,
      updatedAt: serverTimestamp(),
    }, { merge: true });
    localStorage.setItem(`clearspace_workspace_${app.data.user.uid}`, app.data.user.uid);
    app.closeDeleteWorkspace();
    app.closeSettings();
    app.data.currentWorkspaceId = '';
    await ensureWorkspace();
    app.subscribeTasks(); app.subscribeSpaces(); app.subscribeGoals(); app.subscribeBilling();
    await loadAvailableWorkspaces();
    app.navigate('home');
    app.showToast?.(`Workspace “${name}” was permanently deleted.`);
  } catch (error) {
    console.error('Delete workspace failed:', error);
    status.textContent = 'The workspace could not be completely deleted. Please retry.';
  } finally { submit.disabled = false; submit.textContent = 'Delete permanently'; }
};

app.showTeamSettings = function showTeamSettings() {
  if (!app.data.user || !app.data.managedSpaceId) return;
  app.closeProfileMenu();
  renderTeamPanel();
  const modal = document.getElementById('team-modal');
  if (!modal) return;
  modal.inert = false;
  modal.setAttribute('aria-hidden', 'false');
  modal.style.display = 'flex';
  requestAnimationFrame(() => (document.getElementById('team-email') || document.getElementById('managed-space-name') || modal.querySelector('button'))?.focus());
};

app.manageCurrentSpace = function manageCurrentSpaceTeam() {
  const space = app.data.spaces.find((item) => item.id === app.data.currentSpaceId);
  if (!space?.custom || !app.data.user) return;
  app.data.managedSpaceId = space.id;
  app.showTeamSettings();
};

app.renameManagedSpace = async function renameManagedSpace() {
  const space = app.data.spaces.find((item) => item.id === app.data.managedSpaceId);
  const input = document.getElementById('managed-space-name');
  const name = input?.value.trim().replace(/\s+/g, ' ');
  if (!spaceIsManager(space)) return;
  if (!name || app.preventDuplicateSpace(name, space.id)) {
    app.showToast?.(!name ? 'Enter a Space name' : 'That Space name already exists');
    return;
  }
  await updateDoc(doc(window.fbDb, 'clearspace_spaces', space.id), { name, updatedAt: serverTimestamp() });
  space.name = name;
  app.renderSpaces();
  app.updatePageContext();
  renderTeamPanel();
  app.showToast?.('Space name updated');
};

app.deleteManagedSpace = async function deleteManagedSpace() {
  const space = app.data.spaces.find((item) => item.id === app.data.managedSpaceId);
  if (!space?.custom || !spaceIsManager(space)) return;
  const tasks = app.data.tasks.filter((task) => task.spaceId === space.id);
  const message = tasks.length
    ? `Delete “${space.name}”? Its ${tasks.length} task${tasks.length === 1 ? '' : 's'} will be kept and moved to No Space.`
    : `Delete “${space.name}” permanently?`;
  if (!confirm(message)) return;
  const button = document.getElementById('delete-managed-space');
  if (button) { button.disabled = true; button.textContent = 'Deleting...'; }
  try {
    for (let index = 0; index < tasks.length; index += 450) {
      const batch = writeBatch(window.fbDb);
      tasks.slice(index, index + 450).forEach((task) => batch.update(doc(window.fbDb, 'clearspace_tasks', task.id), { spaceId: null, updatedAt: serverTimestamp() }));
      await batch.commit();
    }
    if (app.data.members.length) {
      const memberBatch = writeBatch(window.fbDb);
      app.data.members.forEach((member) => memberBatch.update(doc(window.fbDb, 'clearspace_workspaces', app.data.currentWorkspaceId, 'members', member.userId || member.id), { spaceIds: arrayRemove(space.id), viewSpaceIds: arrayRemove(space.id), editSpaceIds: arrayRemove(space.id) }));
      await memberBatch.commit();
    }
    await deleteDoc(doc(window.fbDb, 'clearspace_spaces', space.id));
    tasks.forEach((task) => { task.spaceId = null; });
    app.data.spaces = app.data.spaces.filter((item) => item.id !== space.id);
    app.data.managedSpaceId = '';
    app.data.currentSpaceId = null;
    app.closeTeamSettings();
    app.renderSpaces();
    app.navigate('home');
    app.showToast?.('Space deleted. Its tasks are still available.');
  } catch (error) {
    console.error('Delete Space failed:', error);
    app.showToast?.('Could not delete the Space. Please retry.');
    if (button?.isConnected) { button.disabled = false; button.textContent = 'Delete Space'; }
  }
};

app.closeTeamSettings = function closeTeamSettings() {
  const modal = document.getElementById('team-modal');
  if (!modal) return;
  modal.style.display = 'none';
  modal.setAttribute('aria-hidden', 'true');
  modal.inert = true;
};

app.sendWorkspaceInvite = async function sendWorkspaceInvite() {
  const managedSpace = app.data.spaces.find((item) => item.id === app.data.managedSpaceId);
  if (!spaceIsManager(managedSpace) || app.data.inviteSaving) return;
  const status = document.getElementById('team-invite-status');
  const submit = document.getElementById('team-send-invite');
  const email = (document.getElementById('team-email')?.value || '').trim();
  const emailLower = normalizedEmail(email);
  const requestedRole = document.getElementById('team-role')?.value || 'member';
  const role = workspaceIsOwner() && requestedRole === 'admin' ? 'admin' : 'member';
  const space = app.data.spaces.find((item) => item.id === app.data.managedSpaceId);
  if (!space) return;
  if (!emailLower || !emailLower.includes('@')) {
    if (status) status.textContent = 'Enter a valid email address.';
    return;
  }
  if ((app.data.blockedEmails || []).some((item) => item.emailLower === emailLower)) {
    if (status) status.textContent = 'That email is blocked in this workspace.';
    return;
  }
  const activeMembers = app.data.members.filter((member) => member.status !== 'removed');
  if (!app.isPro() && activeMembers.length >= 4) {
    app.requirePro('Free workspaces support up to 4 members total. Upgrade to Pro for $15/month for 5+ seats.');
    if (status) status.textContent = 'Upgrade to Pro for $15/month to invite a fifth member.';
    return;
  }
  if (activeMembers.some((member) => (member.email || '').toLowerCase() === emailLower)) {
    if (status) status.textContent = 'That person is already in this workspace.';
    return;
  }
  app.data.inviteSaving = true;
  if (submit) { submit.disabled = true; submit.textContent = 'Sending...'; }
  try {
    const inviteRef = await addDoc(collection(window.fbDb, 'clearspace_workspace_invites'), {
      workspaceId: app.data.currentWorkspaceId,
      workspaceName: workspaceName(),
      spaceId: space.id,
      spaceName: space.name,
      email,
      emailLower,
      role,
      status: 'pending',
      createdBy: app.data.user.uid,
      createdByName: app.data.user.displayName || app.data.user.email || 'Workspace owner',
      createdAt: serverTimestamp(),
    });
    const inviteUrl = `https://clearspacetask.com/signup?invite=${encodeURIComponent(inviteRef.id)}`;
    let emailSent = false;
    let emailError = null;
    for (let attempt = 1; attempt <= 3 && !emailSent; attempt += 1) {
      try {
        const result = await app.billingRequest('/send-space-invite', { inviteId: inviteRef.id });
        if (!result?.sent) throw new Error('The email service did not confirm delivery.');
        emailSent = true;
      } catch (error) {
        emailError = error;
        if (attempt < 3) await new Promise((resolve) => setTimeout(resolve, attempt * 700));
      }
    }
    await updateDoc(inviteRef, {
      emailDeliveryStatus: emailSent ? 'sent' : 'failed',
      emailSentAt: emailSent ? serverTimestamp() : null,
      emailLastAttemptAt: serverTimestamp(),
    });
    if (!emailSent) console.warn('Invite email could not be sent after automatic retries:', emailError);
    document.getElementById('team-email').value = '';
    if (status) status.textContent = emailSent ? `Invitation emailed to ${email}.` : `Invitation added to ${email}'s ClearSpace Inbox. Email delivery is temporarily unavailable.`;
  } catch (error) {
    console.error('Invite failed:', error);
    if (status) status.textContent = 'Could not save that invite. Please retry.';
  } finally {
    app.data.inviteSaving = false;
    if (submit) { submit.disabled = false; submit.textContent = 'Send invite'; }
  }
};

app.sendWholeWorkspaceInvite = async function sendWholeWorkspaceInvite() {
  if (!workspaceIsManager() || app.data.inviteSaving) return;
  const input = document.getElementById('workspace-invite-email');
  const status = document.getElementById('workspace-invite-status');
  const submit = document.getElementById('workspace-invite-button');
  const email = String(input?.value || '').trim();
  const emailLower = normalizedEmail(email);
  const requestedRole = document.getElementById('workspace-invite-role')?.value || 'member';
  const role = workspaceIsOwner() && requestedRole === 'admin' ? 'admin' : 'member';
  if (!emailLower || !emailLower.includes('@')) { status.textContent = 'Enter a valid email address.'; return; }
  if ((app.data.blockedEmails || []).some((item) => item.emailLower === emailLower)) { status.textContent = 'That email is blocked in this workspace.'; return; }
  const activeMembers = app.data.members.filter((member) => member.status !== 'removed');
  if (!app.isPro() && activeMembers.length >= 4) { app.requirePro('Free workspaces support up to 4 members total. Upgrade to Pro for larger teams.'); status.textContent = 'Upgrade to invite another workspace member.'; return; }
  if (activeMembers.some((member) => normalizedEmail(member.email) === emailLower)) { status.textContent = 'That person is already a workspace member. Open a Space to set their access.'; return; }
  app.data.inviteSaving = true;
  submit.disabled = true; submit.textContent = 'Sending…'; status.textContent = '';
  try {
    const inviteRef = await addDoc(collection(window.fbDb, 'clearspace_workspace_invites'), {
      workspaceId: app.data.currentWorkspaceId,
      workspaceName: workspaceName(),
      spaceId: '',
      spaceName: '',
      workspaceAccess: true,
      email,
      emailLower,
      role,
      status: 'pending',
      createdBy: app.data.user.uid,
      createdByName: app.data.user.displayName || app.data.user.email || 'Workspace owner',
      createdAt: serverTimestamp(),
    });
    const result = await app.billingRequest('/send-space-invite', { inviteId: inviteRef.id });
    await updateDoc(inviteRef, { emailDeliveryStatus: result?.sent ? 'sent' : 'failed', emailSentAt: result?.sent ? serverTimestamp() : null, emailLastAttemptAt: serverTimestamp() });
    input.value = '';
    status.textContent = result?.sent ? `Workspace invitation emailed to ${email}.` : 'The invitation was saved, but email delivery was not confirmed.';
  } catch (error) {
    console.error('Workspace invitation failed:', error);
    status.textContent = 'Could not send the workspace invitation. Please retry.';
  } finally { app.data.inviteSaving = false; submit.disabled = false; submit.textContent = 'Invite'; }
};

app.changeWorkspaceRole = async function changeWorkspaceRole(userId, nextRole) {
  const member = app.data.members.find((item) => item.userId === userId);
  if (!workspaceIsOwner() || !member || userId === app.data.user?.uid || !['member', 'admin', 'owner'].includes(nextRole)) { renderWorkspaceSharing(); return; }
  const memberRef = doc(window.fbDb, 'clearspace_workspaces', app.data.currentWorkspaceId, 'members', userId);
  try {
    if (nextRole === 'owner') {
      app.data.pendingOwnerTransferId = userId;
      document.getElementById('transfer-owner-copy').textContent = `Transfer “${workspaceName()}” to ${memberName(member)}? You will become an Admin.`;
      const modal = document.getElementById('transfer-owner-modal');
      modal.inert = false; modal.setAttribute('aria-hidden', 'false'); modal.style.display = 'flex';
      renderWorkspaceSharing();
      return;
    } else {
      await updateDoc(memberRef, { role: nextRole, updatedAt: serverTimestamp() });
      app.showToast?.(`${memberName(member)} is now ${nextRole === 'admin' ? 'an Admin' : 'a User'}.`);
    }
  } catch (error) {
    console.error('Workspace role update failed:', error);
    alert('Could not update that workspace role. Please retry.');
    renderWorkspaceSharing();
  }
};

app.closeOwnerTransfer = function closeOwnerTransfer() {
  const modal = document.getElementById('transfer-owner-modal');
  if (modal) { modal.style.display = 'none'; modal.inert = true; modal.setAttribute('aria-hidden', 'true'); }
  app.data.pendingOwnerTransferId = '';
  renderWorkspaceSharing();
};

app.confirmOwnerTransfer = async function confirmOwnerTransfer() {
  const userId = app.data.pendingOwnerTransferId;
  const member = app.data.members.find((item) => item.userId === userId);
  if (!workspaceIsOwner() || !member) { app.closeOwnerTransfer(); return; }
  try {
    const batch = writeBatch(window.fbDb);
    batch.update(doc(window.fbDb, 'clearspace_workspaces', app.data.currentWorkspaceId), { ownerId: userId, updatedAt: serverTimestamp() });
    batch.update(doc(window.fbDb, 'clearspace_workspaces', app.data.currentWorkspaceId, 'members', userId), { role: 'owner', updatedAt: serverTimestamp() });
    batch.update(doc(window.fbDb, 'clearspace_workspaces', app.data.currentWorkspaceId, 'members', app.data.user.uid), { role: 'admin', updatedAt: serverTimestamp() });
    await batch.commit();
    app.closeOwnerTransfer();
    app.showToast?.(`${memberName(member)} is now the workspace owner.`);
  } catch (error) {
    console.error('Workspace ownership transfer failed:', error);
    alert('Could not transfer workspace ownership. Please retry.');
  }
};

app.setSpacePermission = async function setSpacePermission(userId, permission, enabled) {
  const space = app.data.spaces.find((item) => item.id === app.data.managedSpaceId);
  const member = app.data.members.find((item) => item.userId === userId);
  if (!space || !member || !spaceIsManager(space) || member.role === 'owner' || !['view', 'edit'].includes(permission)) return;
  const memberRef = doc(window.fbDb, 'clearspace_workspaces', app.data.currentWorkspaceId, 'members', userId);
  const spaceRef = doc(window.fbDb, 'clearspace_spaces', space.id);
  try {
    if (permission === 'edit') {
      await updateDoc(memberRef, enabled
        ? { editSpaceIds: arrayUnion(space.id), viewSpaceIds: arrayUnion(space.id), spaceIds: arrayUnion(space.id), updatedAt: serverTimestamp() }
        : { editSpaceIds: arrayRemove(space.id), spaceIds: arrayRemove(space.id), updatedAt: serverTimestamp() });
      await updateDoc(spaceRef, enabled
        ? { editorIds: arrayUnion(userId), memberIds: arrayUnion(userId), updatedAt: serverTimestamp() }
        : { editorIds: arrayRemove(userId), updatedAt: serverTimestamp() });
    } else {
      await updateDoc(memberRef, enabled
        ? { viewSpaceIds: arrayUnion(space.id), updatedAt: serverTimestamp() }
        : { viewSpaceIds: arrayRemove(space.id), editSpaceIds: arrayRemove(space.id), spaceIds: arrayRemove(space.id), updatedAt: serverTimestamp() });
      await updateDoc(spaceRef, enabled
        ? { memberIds: arrayUnion(userId), updatedAt: serverTimestamp() }
        : { memberIds: arrayRemove(userId), editorIds: arrayRemove(userId), updatedAt: serverTimestamp() });
    }
  } catch (error) {
    console.error('Space permission update failed:', error);
    alert('Could not update that Space permission. Please retry.');
    renderTeamPanel();
  }
};

app.blockWorkspaceEmail = async function blockWorkspaceEmail() {
  if (!workspaceIsManager()) return;
  const status = document.getElementById('team-block-status');
  const input = document.getElementById('blocked-email');
  const email = (input?.value || '').trim();
  const emailLower = normalizedEmail(email);
  if (!emailLower || !emailLower.includes('@')) {
    if (status) status.textContent = 'Enter a valid email address.';
    return;
  }
  if (emailLower === normalizedEmail(app.data.user?.email || '')) {
    if (status) status.textContent = 'You cannot block your own email.';
    return;
  }
  if ((app.data.blockedEmails || []).some((item) => item.emailLower === emailLower)) {
    if (status) status.textContent = 'That email is already blocked.';
    return;
  }
  try {
    await setDoc(blockedEmailDoc(app.data.currentWorkspaceId, emailLower), {
      workspaceId: app.data.currentWorkspaceId,
      email,
      emailLower,
      blockedBy: app.data.user.uid,
      blockedByName: app.data.user.displayName || app.data.user.email || 'Workspace owner',
      blockedAt: serverTimestamp(),
    }, { merge: true });
    if (input) input.value = '';
    if (status) status.textContent = `Blocked ${email}. They will no longer be able to join or access this workspace.`;
  } catch (error) {
    console.error('Block email failed:', error);
    if (status) status.textContent = 'Could not block that email. Please retry.';
  }
};

app.unblockWorkspaceEmail = async function unblockWorkspaceEmail(emailLower) {
  if (!workspaceIsManager()) return;
  try {
    await deleteDoc(blockedEmailDoc(app.data.currentWorkspaceId, normalizedEmail(emailLower)));
  } catch (error) {
    console.error('Unblock email failed:', error);
    alert('Could not unblock that email. Please retry.');
  }
};

app.acceptWorkspaceInvite = async function acceptWorkspaceInvite(inviteId, options = {}) {
  if (!app.data.user || !inviteId) return;
  let invite = app.data.inviteInbox.find((item) => item.id === inviteId);
  if (!invite) {
    try {
      const inviteSnapshot = await getDoc(doc(window.fbDb, 'clearspace_workspace_invites', inviteId));
      if (inviteSnapshot.exists()) invite = { id: inviteSnapshot.id, ...inviteSnapshot.data() };
    } catch (error) {
      console.warn('Invitation link could not be loaded directly:', error);
    }
  }
  if (!invite) {
    alert('This invitation could not be found. Ask the workspace owner to send a new invitation.');
    return;
  }
  const emailLower = normalizedEmail(app.data.user.email || invite.email || '');
  if (normalizedEmail(invite.emailLower || invite.email) !== emailLower) {
    alert('Sign in with the same email address that received this invitation.');
    return;
  }
  if ((app.data.blockedEmails || []).some((item) => item.emailLower === emailLower)) {
    alert('Your email is blocked from this workspace.');
    return;
  }
  if (app.data.acceptingInviteId) return;
  app.data.acceptingInviteId = inviteId;
  try {
    const memberRef = doc(window.fbDb, 'clearspace_workspaces', invite.workspaceId, 'members', app.data.user.uid);
    const memberSnapshot = await getDoc(memberRef);
    if (invite.status !== 'pending' && !(invite.status === 'accepted' && invite.acceptedBy === app.data.user.uid && memberSnapshot.exists())) {
      throw new Error('This invitation is no longer available.');
    }

    if (invite.status === 'pending') {
      const batch = writeBatch(window.fbDb);
      if (memberSnapshot.exists()) {
        batch.update(memberRef, {
          inviteId,
          status: 'active',
          ...(invite.spaceId ? {
            spaceIds: arrayUnion(invite.spaceId),
            viewSpaceIds: arrayUnion(invite.spaceId),
            editSpaceIds: arrayUnion(invite.spaceId),
          } : {}),
          updatedAt: serverTimestamp(),
        });
      } else {
        batch.set(memberRef, {
          workspaceId: invite.workspaceId,
          userId: app.data.user.uid,
          email: app.data.user.email || invite.email,
          displayName: app.data.user.displayName || app.data.user.email?.split('@')[0] || 'Member',
          role: invite.role || 'member',
          status: 'active',
          inviteId,
          spaceIds: invite.spaceId ? [invite.spaceId] : [],
          viewSpaceIds: invite.spaceId ? [invite.spaceId] : [],
          editSpaceIds: invite.spaceId ? [invite.spaceId] : [],
          joinedAt: serverTimestamp(),
        });
      }
      batch.update(doc(window.fbDb, 'clearspace_workspace_invites', inviteId), { status: 'accepted', acceptedAt: serverTimestamp(), acceptedBy: app.data.user.uid });
      batch.set(doc(window.fbDb, 'clearspace_users', app.data.user.uid), { workspaceId: invite.workspaceId, currentWorkspaceId: invite.workspaceId, workspaceIds: arrayUnion(invite.workspaceId), workspaceName: invite.workspaceName || 'Workspace', updatedAt: serverTimestamp() }, { merge: true });
      await batch.commit();
    } else {
      // Recover an earlier join that granted membership but did not finish switching workspaces.
      await setDoc(doc(window.fbDb, 'clearspace_users', app.data.user.uid), { workspaceId: invite.workspaceId, currentWorkspaceId: invite.workspaceId, workspaceIds: arrayUnion(invite.workspaceId), workspaceName: invite.workspaceName || 'Workspace', updatedAt: serverTimestamp() }, { merge: true });
    }
    if (invite.spaceId) {
      try {
        await updateDoc(doc(window.fbDb, 'clearspace_spaces', invite.spaceId), { memberIds: arrayUnion(app.data.user.uid), editorIds: arrayUnion(app.data.user.uid), updatedAt: serverTimestamp() });
      } catch (error) {
        // The membership document is authoritative. A stale memberIds list must not prevent joining.
        console.warn('Space member list sync will be retried by the manager:', error);
      }
    }
    app.data.currentWorkspaceId = invite.workspaceId;
    localStorage.setItem(`clearspace_workspace_${app.data.user.uid}`, invite.workspaceId);
    app.data.joinedSpaceId = invite.spaceId || '';
    sessionStorage.removeItem('clearspacePendingInvite');
    if (new URLSearchParams(location.search).has('invite')) history.replaceState({}, '', '/inbox');
    subscribeWorkspace();
    app.subscribeTasks();
    app.subscribeSpaces();
    app.subscribeGoals();
    app.navigate('inbox', { fromRoute: true });
    app.showToast?.(`Joined ${invite.spaceName || invite.workspaceName || 'workspace'}. Opening it now…`);
  } catch (error) {
    console.error('Accept invite failed:', error);
    if (options.fromLink) sessionStorage.setItem('clearspacePendingInvite', inviteId);
    alert('Could not join that Space yet. Make sure you signed in with the email address that received the invitation, then retry.');
  } finally {
    app.data.acceptingInviteId = '';
  }
};

app.removeSpaceMember = async function removeSpaceMember(userId) {
  const spaceId = app.data.managedSpaceId;
  const space = app.data.spaces.find((item) => item.id === spaceId);
  if (!spaceIsManager(space) || !spaceId || userId === app.data.user?.uid) return;
  if (!confirm('Remove this teammate from this Space?')) return;
  try {
    await updateDoc(doc(window.fbDb, 'clearspace_workspaces', app.data.currentWorkspaceId, 'members', userId), { spaceIds: arrayRemove(spaceId), viewSpaceIds: arrayRemove(spaceId), editSpaceIds: arrayRemove(spaceId), updatedAt: serverTimestamp() });
    await updateDoc(doc(window.fbDb, 'clearspace_spaces', spaceId), { memberIds: arrayRemove(userId), editorIds: arrayRemove(userId), updatedAt: serverTimestamp() });
    renderTeamPanel();
  } catch (error) {
    console.error('Remove Space member failed:', error);
    alert('Could not remove that teammate from this Space. Please retry.');
  }
};

app.removeWorkspaceMember = async function removeWorkspaceMember(userId) {
  if (!workspaceIsManager()) return;
  if (!confirm('Remove this member from the workspace?')) return;
  try {
    await deleteDoc(doc(window.fbDb, 'clearspace_workspaces', app.data.currentWorkspaceId, 'members', userId));
  } catch (error) {
    console.error('Remove member failed:', error);
    alert('Could not remove that member. Please retry.');
  }
};

const originalLoadUserData = app.loadUserData.bind(app);
app.loadUserData = async function loadUserDataWithWorkspace() {
  const userData = await originalLoadUserData();
  try {
    await ensureWorkspace(userData);
    await loadAvailableWorkspaces();
  } catch (error) {
    const inaccessibleWorkspace = userData?.currentWorkspaceId || userData?.workspaceId || localStorage.getItem(`clearspace_workspace_${app.data.user.uid}`);
    if (error?.code !== 'permission-denied' || !inaccessibleWorkspace || inaccessibleWorkspace === app.data.user.uid) throw error;
    console.warn('Stored workspace is no longer accessible; returning to the personal workspace.');
    localStorage.removeItem(`clearspace_workspace_${app.data.user.uid}`);
    await ensureWorkspace({ ...userData, workspaceId: app.data.user.uid, currentWorkspaceId: app.data.user.uid, workspaceIds: [app.data.user.uid] });
    await loadAvailableWorkspaces();
  }
  return { ...(userData || {}), workspaceId: app.data.currentWorkspaceId };
};

const originalSubscribeTasks = app.subscribeTasks.bind(app);
app.subscribeTasks = function subscribeTasksByWorkspace() {
  if (!app.data.user || !app.data.currentWorkspaceId) return;
  app.data.unsubTasks?.();
  subscribeWorkspace();
  const q = query(collection(window.fbDb, 'clearspace_tasks'), where('workspaceId', '==', app.data.currentWorkspaceId));
  app.data.unsubTasks = onSnapshot(q, (snap) => {
    app.data.allWorkspaceTasks = snap.docs.map((row) => ({ id: row.id, ...row.data() })).sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
    applyWorkspaceVisibility();
    if (app.data.currentTaskId) {
      const taskStillExists = app.data.tasks.some((task) => task.id === app.data.currentTaskId);
      if (!taskStillExists) app.closeDetail();
      else if (!document.getElementById('detail-panel')?.contains(document.activeElement)) app.openTask(app.data.currentTaskId);
    }
  }, (err) => console.error('Tasks subscription failed:', err));
};

app.subscribeSpaces = function subscribeSpacesByWorkspace() {
  if (!app.data.user || !app.data.currentWorkspaceId) return;
  app.data.unsubSpaces?.();
  const q = query(collection(window.fbDb, 'clearspace_spaces'), where('workspaceId', '==', app.data.currentWorkspaceId));
  app.data.unsubSpaces = onSnapshot(q, (snap) => {
    app.data.allWorkspaceSpaces = snap.docs.map((row) => ({ id: row.id, ...row.data(), icon: window.csIcon('folder'), custom: true }));
    applyWorkspaceVisibility();
    if (app.data.joinedSpaceId && app.data.allWorkspaceSpaces.some((space) => space.id === app.data.joinedSpaceId)) {
      const joinedSpaceId = app.data.joinedSpaceId;
      app.data.joinedSpaceId = '';
      app.selectSpace(joinedSpaceId);
    }
    if (location.pathname.startsWith('/spaces/')) app.routeAuthenticatedLocation();
  }, (err) => console.error('Spaces subscription failed:', err));
};

app.subscribeGoals = function subscribeGoalsByWorkspace() {
  if (!app.data.user || !app.data.currentWorkspaceId) return;
  app.data.unsubGoals?.();
  const q = query(collection(window.fbDb, 'clearspace_goals'), where('workspaceId', '==', app.data.currentWorkspaceId));
  app.data.unsubGoals = onSnapshot(q, (snap) => {
    app.data.goals = snap.docs.map((row) => ({ id: row.id, ...row.data() })).sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
    app.renderGoals();
    if (location.pathname.startsWith('/goals/')) app.routeAuthenticatedLocation();
    else if (app.data.currentPage === 'goal') app.renderContent();
  }, (err) => console.error('Goals subscription failed:', err));
};

app.subscribeBilling = function subscribeBillingByWorkspace() {
  if (!app.data.user || !app.data.currentWorkspaceId) return;
  app.data.unsubBilling?.();
  app.data.unsubAccountBilling?.();
  const freeBilling = () => ({ plan: 'free', status: 'inactive', stripeCustomerId: '', stripeSubscriptionId: '' });
  const applyBilling = () => {
    const account = app.data.accountBilling;
    const hasAccountGrant = account?.scope === 'account' && account.plan === 'pro' && ['active', 'trialing'].includes(account.status);
    app.data.billing = hasAccountGrant
      ? { ...account, complimentary: true, entitlementSource: 'account' }
      : (app.data.workspaceBilling || freeBilling());
    app.updateBillingUI();
  };
  const workspaceId = app.data.currentWorkspaceId;
  app.data.unsubBilling = onSnapshot(doc(window.fbDb, 'clearspace_billing', workspaceId), (snapshot) => {
    app.data.workspaceBilling = snapshot.exists() ? { ...freeBilling(), ...snapshot.data() } : freeBilling();
    if (workspaceId === app.data.user.uid) app.data.accountBilling = app.data.workspaceBilling;
    applyBilling();
  }, (error) => console.error('Workspace billing subscription failed:', error));
  if (workspaceId !== app.data.user.uid) {
    app.data.unsubAccountBilling = onSnapshot(doc(window.fbDb, 'clearspace_billing', app.data.user.uid), (snapshot) => {
      app.data.accountBilling = snapshot.exists() ? { ...freeBilling(), ...snapshot.data() } : freeBilling();
      applyBilling();
    }, (error) => console.error('Account entitlement subscription failed:', error));
  } else {
    app.data.unsubAccountBilling = null;
  }
};

const originalBillingRequest = app.billingRequest.bind(app);
app.billingRequest = function workspaceBillingRequest(path, payload = null) {
  return originalBillingRequest(path, { ...(payload || {}), workspaceId: app.data.currentWorkspaceId });
};

const originalAuthenticatedApiRequest = app.authenticatedApiRequest.bind(app);
app.authenticatedApiRequest = function workspaceApiRequest(path, method = 'GET', payload = null) {
  const separator = path.includes('?') ? '&' : '?';
  const workspacePath = `${path}${separator}workspaceId=${encodeURIComponent(app.data.currentWorkspaceId || '')}`;
  const normalizedMethod = String(method || 'GET').toUpperCase();
  const requestPayload = ['GET', 'HEAD'].includes(normalizedMethod)
    ? null
    : { ...(payload || {}), workspaceId: app.data.currentWorkspaceId };
  return originalAuthenticatedApiRequest(workspacePath, normalizedMethod, requestPayload);
};

const originalUpdateBillingUI = app.updateBillingUI.bind(app);
app.updateBillingUI = function updateBillingUIWithSeats() {
  originalUpdateBillingUI();
  if (app.data.billing?.complimentary) {
    const manageButton = document.getElementById('manage-subscription');
    const status = document.getElementById('billing-status');
    if (manageButton) manageButton.style.display = 'none';
    if (status) status.textContent = 'Complimentary ClearSpace Pro is active for this account in every workspace.';
  }
  if (app.data.workspace?.ownerId === app.data.user?.uid && app.data.currentWorkspaceId) {
    void setDoc(doc(window.fbDb, 'clearspace_workspaces', app.data.currentWorkspaceId), {
      plan: app.isPro() ? 'pro' : 'free',
      seatLimit: workspaceSeatLimit(),
      updatedAt: serverTimestamp(),
    }, { merge: true });
  }
  syncCollaboratorUI();
};

const originalUpdateProfileUI = app.updateProfileUI.bind(app);
app.updateProfileUI = function updateProfileUIWithWorkspace() {
  originalUpdateProfileUI();
  syncCollaboratorUI();
};

const originalRenderInbox = app.renderInbox.bind(app);
app.renderInbox = function renderInboxWithSpaceInvites() {
  const invites = app.data.inviteInbox || [];
  if (!invites.length) return originalRenderInbox();
  const container = document.getElementById('content-area');
  container.innerHTML = `<div class="pm-fade-in" style="display:grid;gap:14px;max-width:760px;"><div class="pm-customize-section"><h2 style="margin:0 0 6px;">Space invitations</h2><p style="margin:0;color:#6b7280;">Workspace invitations also appear here. Join either one to collaborate with its team.</p></div>${invites.map((invite) => { const wholeWorkspace = !invite.spaceId; const roleLabel = invite.role === 'admin' ? 'Admin' : 'User'; return `<article class="pm-customize-section" style="display:flex;align-items:center;justify-content:space-between;gap:16px;"><div><div style="font-weight:750;font-size:16px;">${app.escapeHTML(invite.spaceName || invite.workspaceName || 'Shared workspace')}</div><div style="margin-top:4px;color:#6b7280;font-size:13px;">${app.escapeHTML(invite.createdByName || 'A teammate')} invited you to join this ${wholeWorkspace ? 'workspace' : 'Space'} as ${roleLabel === 'Admin' ? 'an' : 'a'} ${roleLabel}.</div></div><button class="pm-btn-primary" aria-label="Join Space or workspace" onclick="app.acceptWorkspaceInvite('${invite.id}')">Join ${wholeWorkspace ? 'Workspace' : 'Space'}</button></article>`; }).join('')}</div>`;
};

const originalUpdatePageContext = app.updatePageContext.bind(app);
app.updatePageContext = function updatePageContextWithWorkspaceName() {
  originalUpdatePageContext();
  if ((app.data.currentSpaceId ? 'space' : app.data.currentPage) === 'home') {
    document.getElementById('page-title').textContent = workspaceName();
    document.getElementById('breadcrumb').textContent = workspaceName();
  }
};

const originalRenderCreateFields = app.renderCreateFields.bind(app);
app.renderCreateFields = function renderCreateFieldsWithTeamAssignees() {
  originalRenderCreateFields();
  const select = document.getElementById('new-task-assignee');
  if (select) select.innerHTML = assigneeOptionsHTML(select.value || 'unassigned', document.getElementById('new-task-space')?.value || app.data.currentSpaceId || '');
};

const originalCreateTask = app.createTask.bind(app);
app.createTask = function createTaskWithTeamAssignees() {
  originalCreateTask();
  const select = document.getElementById('new-task-assignee');
  if (select) select.innerHTML = assigneeOptionsHTML(select.value || 'unassigned', document.getElementById('new-task-space')?.value || app.data.currentSpaceId || '');
  const spaceSelect = document.getElementById('new-task-space');
  if (spaceSelect && !spaceSelect.dataset.teamAssigneeBound) {
    spaceSelect.dataset.teamAssigneeBound = 'true';
    spaceSelect.addEventListener('change', () => {
      const assignee = document.getElementById('new-task-assignee');
      if (assignee) assignee.innerHTML = assigneeOptionsHTML(assignee.value || app.data.user?.uid || 'unassigned', spaceSelect.value || '');
    });
  }
};

app.saveTask = async function saveTaskWithWorkspace() {
  if (app.data.taskSaving) return;
  if (!app.data.user) { alert('Please sign in first.'); return; }
  const name = document.getElementById('new-task-name').value.trim();
  const error = document.getElementById('create-task-error');
  const submit = document.getElementById('create-task-submit');
  error.style.display = 'none';
  if (!name) { error.textContent = 'Task name is required.'; error.style.display = 'block'; return; }
  const tags = (document.getElementById('new-task-tags')?.value || '').split(/[,.\n]/).map((tag) => tag.trim()).filter(Boolean).slice(0, 10);
  const assigneeValue = document.getElementById('new-task-assignee')?.value || 'unassigned';
  const selectedSpaceId = document.getElementById('new-task-space')?.value || app.data.currentSpaceId || null;
  if (selectedSpaceId && !memberCanEditSpace(currentMember(), selectedSpaceId)) {
    error.textContent = 'You have view-only access to this Space. Ask a workspace owner for edit access.';
    error.style.display = 'block';
    return;
  }
  const selectedMember = app.data.members.find((member) => member.userId === assigneeValue && (!selectedSpaceId || memberCanEditSpace(member, selectedSpaceId)));
  const newTask = {
    name,
    status: document.getElementById('new-task-status')?.value || 'todo',
    priority: (document.getElementById('new-task-priority')?.value || 'medium').toLowerCase(),
    assignee: selectedMember ? memberName(selectedMember) : 'Unassigned',
    assigneeId: selectedMember ? selectedMember.userId : null,
    spaceId: selectedSpaceId,
    due: document.getElementById('new-task-due')?.value || '',
    recurring: app.getCreateRecurrence().frequency,
    recurrence: app.getCreateRecurrence(),
    recurrenceOccurrence: 1,
    tags,
    project: document.getElementById('new-task-project')?.value?.trim() || '',
    description: document.getElementById('new-task-desc')?.value?.trim() || '',
    estimate: document.getElementById('new-task-estimate')?.value?.trim() || '',
    visibleFields: ['priority', 'due', ...app.data.createFields],
    subtasks: [],
    time: '0h 00m',
    timeSeconds: 0,
    userId: app.data.user.uid,
    ownerId: app.data.workspace?.ownerId || app.data.user.uid,
    workspaceId: app.data.currentWorkspaceId || app.data.workspace?.id || app.data.user?.uid,
    createdAt: serverTimestamp(),
  };
  app.data.taskSaving = true;
  submit.disabled = true;
  submit.textContent = 'Creating...';
  try {
    const created = await addDoc(collection(window.fbDb, 'clearspace_tasks'), newTask);
    const optimisticTask = { ...newTask, id: created.id, createdAt: { seconds: Math.floor(Date.now() / 1000) } };
    await app.recordFirstTaskActivation?.();
    app.data.tasks = [optimisticTask, ...app.data.tasks.filter((task) => task.id !== created.id)];
    app.renderContent();
    app.updateNavigationCounts();
    await app.syncTaskToGoogleCalendar?.(optimisticTask);
    app.closeModal();
  } catch (err) {
    console.error('Task creation failed:', err);
    error.textContent = 'Could not create the task. Check your connection and retry.';
    error.style.display = 'block';
  } finally {
    app.data.taskSaving = false;
    submit.disabled = false;
    submit.textContent = 'Create Task';
  }
};

const originalRenderEditableTaskField = app.renderEditableTaskField.bind(app);
app.renderEditableTaskField = function renderEditableTaskFieldWithMembers(task, field) {
  if (field !== 'assignee') return originalRenderEditableTaskField(task, field);
  const removable = !['priority', 'due'].includes(field);
  const remove = removable ? `<button class="pm-detail-field-remove" onclick="app.removeTaskField('${task.id}', '${field}')" title="Hide field" aria-label="Hide field">&times;</button>` : '';
  const wrap = (label, value) => `<div class="pm-detail-field" data-task-field="${field}"><div class="pm-detail-field-label">${label}${remove}</div><div class="pm-detail-field-value">${value}</div></div>`;
  return wrap('Assignee', `<select class="pm-detail-edit" onchange="app.updateTaskField('${task.id}', 'assignee', this.value)">${assigneeOptionsHTML(task.assigneeId || 'unassigned', task.spaceId || '')}</select>`);
};

const originalUpdateTaskField = app.updateTaskField.bind(app);
app.updateTaskField = async function updateTaskFieldWithMembers(taskId, field, value) {
  if (field !== 'assignee') return originalUpdateTaskField(taskId, field, value);
  const task = app.data.tasks.find((item) => item.id === taskId);
  if (!task) return;
  const selectedMember = app.data.members.find((member) => member.userId === value && (!task.spaceId || memberCanEditSpace(member, task.spaceId)));
  const previousAssignee = task.assignee;
  const previousAssigneeId = task.assigneeId;
  task.assignee = selectedMember ? memberName(selectedMember) : 'Unassigned';
  task.assigneeId = selectedMember ? selectedMember.userId : null;
  try {
    await updateDoc(doc(window.fbDb, 'clearspace_tasks', taskId), { assignee: task.assignee, assigneeId: task.assigneeId, updatedAt: serverTimestamp() });
  } catch (error) {
    task.assignee = previousAssignee;
    task.assigneeId = previousAssigneeId;
    console.error('Task assignee update failed:', error);
    alert('Could not update this assignee. Please retry.');
  }
};

injectTeamsUI();
syncCollaboratorUI();
document.addEventListener('click', (event) => { if (!document.getElementById('workspace-switcher')?.contains(event.target)) app.closeWorkspaceSwitcher?.(); });


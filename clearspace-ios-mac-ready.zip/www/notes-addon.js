const app = window.app;
if (!app) throw new Error('ClearSpace app was not loaded before notes-addon.js');

const { collection, doc, addDoc, updateDoc, deleteDoc, onSnapshot, query, where, serverTimestamp } = window.fb;

const styles = document.createElement('style');
styles.textContent = `
  .cs-notes-shell{display:grid;grid-template-columns:minmax(220px,310px) minmax(0,1fr);min-height:min(680px,calc(100vh - 220px));border:1px solid rgba(125,84,52,.14);border-radius:20px;overflow:hidden;background:rgba(255,255,255,.9);box-shadow:0 18px 44px rgba(95,62,39,.08)}
  .cs-notes-list-panel{display:flex;min-width:0;flex-direction:column;border-right:1px solid #ece7e2;background:linear-gradient(180deg,#fffaf5,#fff)}
  .cs-notes-list-head{padding:18px;border-bottom:1px solid #eee8e2}.cs-notes-list-title{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px}.cs-notes-list-title strong{font-size:16px}
  .cs-notes-search{width:100%;border:1px solid #ded8d2;border-radius:12px;padding:10px 12px;background:#fff;color:#172033;font:inherit;outline:none}.cs-notes-search:focus{border-color:var(--accent);box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 15%,transparent)}
  .cs-notes-list{padding:10px;overflow:auto;display:grid;align-content:start;gap:6px}.cs-note-item{width:100%;min-width:0;padding:13px;border:0;border-radius:13px;background:transparent;color:inherit;text-align:left;cursor:pointer}.cs-note-item:hover{background:#f7efe7}.cs-note-item.active{background:#f1e3d5;box-shadow:inset 3px 0 var(--accent)}
  .cs-note-item-title{font-weight:750;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.cs-note-item-preview{margin-top:5px;color:#7b726b;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.cs-note-item-time{margin-top:7px;color:#a19891;font-size:11px}
  .cs-note-editor{display:flex;min-width:0;flex-direction:column;background:#fff}.cs-note-editor-head{display:flex;align-items:center;gap:10px;padding:14px 18px;border-bottom:1px solid #eee8e2}.cs-note-save-state{margin-left:auto;color:#7d746d;font-size:12px}.cs-note-delete{color:#b42318!important}
  .cs-note-title{width:100%;border:0;background:transparent;padding:24px 28px 8px;color:#172033;font:800 clamp(22px,3vw,30px)/1.2 inherit;outline:none}.cs-note-body{width:100%;flex:1;min-height:420px;resize:none;border:0;background:transparent;padding:14px 28px 32px;color:#364152;font:15px/1.75 inherit;outline:none}.cs-note-body::placeholder,.cs-note-title::placeholder{color:#aaa29b}
  .cs-notes-empty{display:grid;place-items:center;min-height:480px;padding:30px;text-align:center}.cs-notes-empty-inner{max-width:350px}.cs-notes-empty-icon{width:64px;height:64px;display:grid;place-items:center;margin:0 auto 16px;border-radius:19px;background:linear-gradient(145deg,#f6dfc3,#edbd88);color:#824c2d}.cs-notes-empty h2{margin:0 0 8px;font-size:21px}.cs-notes-empty p{margin:0 0 18px;color:#716860;line-height:1.6}
  body.theme-dark .cs-notes-shell,body.theme-dark .cs-note-editor{background:#111827;border-color:#334155}body.theme-dark .cs-notes-list-panel{background:linear-gradient(180deg,#172033,#111827);border-color:#334155}body.theme-dark .cs-notes-list-head,body.theme-dark .cs-note-editor-head{border-color:#334155}body.theme-dark .cs-note-item:hover{background:#263246}body.theme-dark .cs-note-item.active{background:#303b51}body.theme-dark .cs-note-title,body.theme-dark .cs-note-body,body.theme-dark .cs-notes-search{color:#f8fafc;background:#111827;border-color:#475569}
  @media(max-width:720px){.cs-notes-shell{grid-template-columns:1fr;min-height:calc(100vh - 190px)}.cs-notes-list-panel{border-right:0;border-bottom:1px solid #ece7e2;max-height:245px}.cs-notes-list{grid-template-columns:repeat(auto-fit,minmax(190px,1fr));overflow:auto}.cs-note-title{padding:20px 20px 7px}.cs-note-body{min-height:340px;padding:12px 20px 24px}}
`;
document.head.appendChild(styles);

Object.assign(app.data, { notes: [], selectedNoteId: '', noteSearch: '', unsubNotes: null, noteSaveTimer: null });

const workspaceId = () => app.data.currentWorkspaceId || app.data.workspace?.id || app.data.user?.uid || '';
const noteUpdatedMs = (note) => note.updatedAt?.toMillis?.() || note.updatedAt?.seconds * 1000 || note.createdAt?.toMillis?.() || note.createdAt?.seconds * 1000 || 0;
const noteTimestamp = (note) => {
  const ms = noteUpdatedMs(note);
  if (!ms) return 'Just now';
  return new Intl.DateTimeFormat(undefined, { month:'short', day:'numeric', ...(new Date(ms).getFullYear() !== new Date().getFullYear() ? { year:'numeric' } : {}) }).format(new Date(ms));
};

app.subscribeNotes = function subscribeNotes() {
  app.data.unsubNotes?.();
  app.data.unsubNotes = null;
  if (!app.data.user || !workspaceId()) return;
  const subscribedWorkspace = workspaceId();
  const notesQuery = query(collection(window.fbDb, 'clearspace_notes'), where('workspaceId', '==', subscribedWorkspace));
  app.data.unsubNotes = onSnapshot(notesQuery, (snapshot) => {
    if (subscribedWorkspace !== workspaceId()) return;
    app.data.notes = snapshot.docs.map((row) => ({ id:row.id, ...row.data() })).sort((a,b) => noteUpdatedMs(b) - noteUpdatedMs(a));
    if (app.data.selectedNoteId && !app.data.notes.some((note) => note.id === app.data.selectedNoteId)) app.data.selectedNoteId = '';
    if (!app.data.selectedNoteId && app.data.notes.length) app.data.selectedNoteId = app.data.notes[0].id;
    const count = document.getElementById('notes-count');
    if (count) count.textContent = String(app.data.notes.length);
    if (app.data.currentPage === 'notes') app.renderNotes({ preserveEditor: document.activeElement?.closest?.('.cs-note-editor') });
  }, (error) => {
    console.error('Notes subscription failed:', error);
    if (app.data.currentPage === 'notes') app.showToast?.('Could not load notes. Please retry.');
  });
};

app.renderNoteList = function renderNoteList() {
  const list = document.getElementById('notes-list');
  if (!list) return;
  const search = app.data.noteSearch.trim().toLowerCase();
  const notes = app.data.notes.filter((note) => !search || `${note.title || ''} ${note.body || ''}`.toLowerCase().includes(search));
  list.innerHTML = notes.length ? notes.map((note) => {
    const title = String(note.title || '').trim() || 'Untitled note';
    const preview = String(note.body || '').trim().replace(/\s+/g, ' ') || 'No additional text';
    return `<button class="cs-note-item ${note.id === app.data.selectedNoteId ? 'active' : ''}" onclick="app.selectNote('${note.id}')"><div class="cs-note-item-title">${app.escapeHTML(title)}</div><div class="cs-note-item-preview">${app.escapeHTML(preview)}</div><div class="cs-note-item-time">${noteTimestamp(note)}</div></button>`;
  }).join('') : `<div style="padding:24px 12px;text-align:center;color:#81776f;font-size:13px;">${search ? 'No notes match your search.' : 'No notes yet.'}</div>`;
};

app.renderNotes = function renderNotes(options = {}) {
  const container = document.getElementById('content-area');
  if (!container) return;
  const note = app.data.notes.find((item) => item.id === app.data.selectedNoteId);
  const existingEditor = container.querySelector('.cs-note-editor');
  if (options.preserveEditor && existingEditor && note) { app.renderNoteList(); return; }
  container.innerHTML = `<div class="cs-notes-shell pm-fade-in"><aside class="cs-notes-list-panel"><div class="cs-notes-list-head"><div class="cs-notes-list-title"><strong>Your notes</strong><button class="pm-btn-primary" onclick="app.createNote()" aria-label="Create note"><span data-cs-icon="plus"></span> New</button></div><input class="cs-notes-search" type="search" placeholder="Search notes" aria-label="Search notes" value="${app.escapeHTML(app.data.noteSearch)}" oninput="app.searchNotes(this.value)"></div><div class="cs-notes-list" id="notes-list"></div></aside>${note ? `<section class="cs-note-editor"><div class="cs-note-editor-head"><span data-cs-icon="edit"></span><span class="cs-note-save-state" id="note-save-state">Saved</span><button class="pm-btn-icon cs-note-delete" onclick="app.deleteNote('${note.id}')" title="Delete note" aria-label="Delete note"><span data-cs-icon="trash"></span></button></div><input class="cs-note-title" id="note-title" maxlength="160" placeholder="Untitled note" aria-label="Note title" value="${app.escapeHTML(note.title || '')}" oninput="app.queueNoteSave('${note.id}')"><textarea class="cs-note-body" id="note-body" placeholder="Write anything here…" aria-label="Note text" oninput="app.queueNoteSave('${note.id}')">${app.escapeHTML(note.body || '')}</textarea></section>` : `<section class="cs-notes-empty"><div class="cs-notes-empty-inner"><div class="cs-notes-empty-icon">${window.csIcon('edit')}</div><h2>Capture what matters</h2><p>Keep meeting notes, ideas, checklists, and project details beside the rest of your workspace.</p><button class="pm-btn-primary" onclick="app.createNote()"><span data-cs-icon="plus"></span> Create your first note</button></div></section>`}</div>`;
  app.renderNoteList();
  window.csHydrateIcons?.(container);
};

app.searchNotes = function searchNotes(value) { app.data.noteSearch = String(value || ''); app.renderNoteList(); };
app.selectNote = function selectNote(id) { app.flushNoteSave(); app.data.selectedNoteId = id; app.renderNotes(); };

app.createNote = async function createNote() {
  if (!app.data.user || !workspaceId()) return;
  try {
    const created = await addDoc(collection(window.fbDb, 'clearspace_notes'), { title:'', body:'', workspaceId:workspaceId(), userId:app.data.user.uid, ownerId:app.data.workspace?.ownerId || app.data.user.uid, createdBy:app.data.user.uid, createdAt:serverTimestamp(), updatedAt:serverTimestamp() });
    app.data.selectedNoteId = created.id;
    app.data.noteSearch = '';
    app.renderNotes();
    requestAnimationFrame(() => document.getElementById('note-title')?.focus());
  } catch (error) { console.error('Create note failed:', error); app.showToast?.('Could not create the note. Please retry.'); }
};

app.queueNoteSave = function queueNoteSave(id) {
  const title = document.getElementById('note-title')?.value || '';
  const body = document.getElementById('note-body')?.value || '';
  const note = app.data.notes.find((item) => item.id === id);
  if (note) { note.title = title; note.body = body; }
  const state = document.getElementById('note-save-state');
  if (state) state.textContent = 'Saving…';
  app.renderNoteList();
  clearTimeout(app.data.noteSaveTimer);
  app.data.noteSaveTimer = setTimeout(() => app.saveNote(id, title, body), 650);
};

app.saveNote = async function saveNote(id, title, body) {
  app.data.noteSaveTimer = null;
  try {
    await updateDoc(doc(window.fbDb, 'clearspace_notes', id), { title:String(title).slice(0,160), body:String(body).slice(0,100000), updatedAt:serverTimestamp(), updatedBy:app.data.user.uid });
    const state = document.getElementById('note-save-state');
    if (state && app.data.selectedNoteId === id) state.textContent = 'Saved';
  } catch (error) {
    console.error('Save note failed:', error);
    const state = document.getElementById('note-save-state');
    if (state && app.data.selectedNoteId === id) state.textContent = 'Could not save';
  }
};

app.flushNoteSave = function flushNoteSave() {
  if (!app.data.noteSaveTimer || !app.data.selectedNoteId) return;
  clearTimeout(app.data.noteSaveTimer);
  app.data.noteSaveTimer = null;
  const title = document.getElementById('note-title')?.value || '';
  const body = document.getElementById('note-body')?.value || '';
  void app.saveNote(app.data.selectedNoteId, title, body);
};

app.deleteNote = async function deleteNote(id) {
  const note = app.data.notes.find((item) => item.id === id);
  if (!confirm(`Delete "${String(note?.title || '').trim() || 'Untitled note'}" permanently?`)) return;
  clearTimeout(app.data.noteSaveTimer); app.data.noteSaveTimer = null;
  try { await deleteDoc(doc(window.fbDb, 'clearspace_notes', id)); app.data.selectedNoteId = ''; }
  catch (error) { console.error('Delete note failed:', error); app.showToast?.('Could not delete the note. Please retry.'); }
};

const originalNavigate = app.navigate.bind(app);
app.navigate = function navigateWithNotes(view, options = {}) {
  if (view !== 'notes') return originalNavigate(view, options);
  if (app.data.currentTaskId) void app.closeDetail();
  app.flushNoteSave();
  app.closeCustomizePanel();
  app.data.currentPage = 'notes'; app.data.currentSpaceId = null; app.data.currentGoal = null;
  document.querySelectorAll('.pm-nav-item').forEach((item) => item.classList.remove('active'));
  document.querySelector('.pm-nav-item[data-view="notes"]')?.classList.add('active');
  app.renderNotes(); app.updatePageContext();
  if (!options.fromRoute) app.setRoute('/notes');
  if (window.matchMedia('(max-width:1024px)').matches) app.closeMobileSidebar();
};

const originalRenderContent = app.renderContent.bind(app);
app.renderContent = function renderContentWithNotes() {
  if (app.data.currentPage === 'notes') return app.renderNotes({ preserveEditor: document.activeElement?.closest?.('.cs-note-editor') });
  return originalRenderContent();
};

const originalSearch = app.search.bind(app);
app.search = function searchWithNotes(value) {
  if (app.data.currentPage === 'notes') return app.searchNotes(value);
  return originalSearch(value);
};

const originalRouteAuthenticatedLocation = app.routeAuthenticatedLocation.bind(app);
app.routeAuthenticatedLocation = function routeAuthenticatedLocationWithNotes() {
  if (location.pathname === '/notes') return app.navigate('notes', { fromRoute:true });
  return originalRouteAuthenticatedLocation();
};

const originalUpdatePageContext = app.updatePageContext.bind(app);
app.updatePageContext = function updatePageContextWithNotes() {
  originalUpdatePageContext();
  if (app.data.currentPage !== 'notes') return;
  document.getElementById('page-title').textContent = 'Notes';
  document.getElementById('page-subtitle').textContent = 'Capture ideas and details in this workspace.';
  document.getElementById('breadcrumb').textContent = 'Notes';
  document.getElementById('context-actions').innerHTML = '<button class="pm-btn-primary" onclick="app.createNote()"><span data-cs-icon="plus"></span> New note</button>';
  document.getElementById('toolbar').style.display = 'none';
  window.csHydrateIcons?.(document.getElementById('context-actions'));
};

const originalSubscribeTasks = app.subscribeTasks.bind(app);
app.subscribeTasks = function subscribeTasksWithNotes() { const result = originalSubscribeTasks(); app.subscribeNotes(); return result; };

const originalLogout = app.logout.bind(app);
app.logout = async function logoutWithNotes() { app.flushNoteSave(); app.data.unsubNotes?.(); app.data.unsubNotes = null; return originalLogout(); };

window.addEventListener('beforeunload', () => app.flushNoteSave());

# ClearSpace for iOS

This folder wraps the existing ClearSpace web application in a native iOS shell using Capacitor.

## App identity

- Name: ClearSpace
- Bundle identifier: `com.clearspacetask.app`
- Website: `https://clearspacetask.com/`

## Windows setup

Run these commands in this folder:

```powershell
npm install
npm run ios:add
npm run ios:sync
```

This prepares the project and copies the current files from `../firebase-public` into the iOS application.

## Apple build

Apple requires Xcode on macOS to compile, sign, test on an iPhone, and submit to the App Store. Move or check out the complete project on a Mac, then run:

```bash
cd ios-app
npm install
npm run ios:sync
npm run ios:open
```

In Xcode, select the ClearSpace development team and signing certificate, choose an iPhone simulator or device, and run the app.

## Before App Store submission

- Configure native Google sign-in or an external-browser OAuth return flow.
- Configure Apple Sign in if Google sign-in remains available.
- Add a native subscription flow using Apple In-App Purchase for digital Pro access.
- Test task creation, Spaces, invitations, templates, recurring tasks, Google Calendar, notifications, and deep links on a real iPhone.
- Create all required App Store screenshots and privacy disclosures.
